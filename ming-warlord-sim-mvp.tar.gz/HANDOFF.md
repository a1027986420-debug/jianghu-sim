# 江湖模拟器 — AI 交接包

给接手开发的 AI / 工程师：本包是 **可运行源码快照**（无 `node_modules`、无 `.next`、无 `.git`、无真实 API Key）。产品对标《历史模拟器：崇祯》的信息密度与水墨气质，玩法是 **普通人游历江湖**，不是掌门发令，也不是纯文字聊天。

生成日期：2026-11-05（Asia/Shanghai）  
当前线上测试：http://154.12.21.230:3301  
Origin 草稿（若仍有效）：https://origin.cursor.com/git/ruby-diaz/tmp-9f38875495e1b34a.git  
云端代理页：https://cursor.com/agents/bc-85110c8c-d91b-511e-a6fa-88ee849e0eac

---

## 1. 产品目标（已拍板）

- **开局**：普通人（猎户子 / 落魄书生 / 逃奴 / 货郎），青石渡 / 客栈入江湖。**禁止**开局掌门、禁止一上来门派宫斗推演。
- **气质**：水墨风——宣纸米白、淡墨、焦墨字、朱砂强调；立绘、山水卷轴地图、功法图谱、回合擂台。
- **四大模块（MVP 已有最小可玩）**
  1. 会客立绘（左立绘 + 对话 + 行动草稿）
  2. 江湖地图（至少 6 朱印据点，旅行耗银两/时辰）
  3. 功法图谱（身法 / 兵器 / 内息 / 识人，约 16 节点，耗感悟点）
  4. **传统回合制战斗**（本地公式定胜负；LLM 只写战报/喊话微调，**不得**用模型判输赢）
- **中后期**：入门执事、开山立派等是结局线，不是默认身份。
- **对标参考**：崇祯模拟器的诏书台 / 大地图 / 立绘对话 / 国策树 —— 布局信息密度可学，玩法要翻成「行路 / 见人 / 学艺 / 动手」。

---

## 2. 技术栈

- Next.js App Router + React + TypeScript + Tailwind
- 包名：`jianghu-simulator@0.1.0`
- LLM：OpenAI 兼容 DeepSeek  
  - `OPENAI_BASE_URL=https://api.deepseek.com`  
  - `OPENAI_MODEL=deepseek-flash`  
  - 请求 `${BASE}/v1/chat/completions`  
  - `content` 为空时回退读 `reasoning_content`
- 无 Key 时：本地规则推演仍可玩通（`npm run check` 离线闭环）
- 会话：服务端进程内存 + 浏览器 `localStorage` 续玩（公开测试单进程即可）

### 关键脚本

```bash
npm install
npm run dev      # :3300
npm run build && npm start
npm run check    # 离线：出身→巷战→学一式→赶县城
```

### 环境变量

见包内 `.env.example`。**真实密钥只放部署机 `.env`（chmod 600），禁止进仓库/交接正文。**

| 变量 | 说明 |
| --- | --- |
| OPENAI_API_KEY | 可空 |
| OPENAI_BASE_URL | 默认 api.deepseek.com |
| OPENAI_MODEL | 默认 deepseek-flash |
| PORT | 默认 3300 |

健康检查：`GET /api/health` → `{ ok, llmConfigured, model, ... }`

---

## 3. 目录地图（先读这些）

```
jianghu-sim/
  app/page.tsx                 # 选出身
  app/road/page.tsx            # 会客
  app/road/map/page.tsx        # 地图
  app/road/arts/page.tsx       # 功法图谱
  app/road/fight/page.tsx      # 战斗页
  app/api/game/route.ts        # 推演 / 行动
  app/api/session/route.ts     # 会话
  app/api/health/route.ts
  components/shell.tsx         # 水墨壳 + 顶栏
  components/talk-view.tsx
  components/scroll-map.tsx
  components/arts-view.tsx
  components/combat-view.tsx
  components/ink-figures.tsx   # 立绘 SVG/水墨形
  lib/game/types.ts
  lib/game/state.ts
  lib/game/engine.ts
  lib/game/combat.ts           # 回合公式（胜负真相源）
  lib/game/sim.ts / llm.ts     # 推演与模型
  lib/game/catalog.ts / canon.ts
  scripts/playthrough.ts       # check 用
```

### 路由

| 路径 | 作用 |
| --- | --- |
| `/` | 选出身 |
| `/road` | 会客 |
| `/road/map` | 山水卷轴 6 据点 |
| `/road/arts` | 功法图谱 |
| `/road/fight` | 回合战 |

顶栏数值：银两、健康/伤势、武功粗档、传闻、人情、感悟。

---

## 4. 战斗公式（接手时勿改成「模型说了算」）

摘要（以 `lib/game/combat.ts` 为准）：

- 身法高者先手
- 命中约：`55 + (兵器 + 身法×0.35 − 招架 − 对方身法×0.25) × 1.5`，夹在约 18%–93%
- 伤害：兵器伤 − 招架，防守再削，至少 1
- 状态：流血、内伤、破防
- AI：莽夫猛攻；老狐狸残血偏防反
- 战中喊话：只微调命中/伤害几点
- LLM：在线时补刀风文案，**不改血量**

按钮：攻 / 防 / 功法 / 道具 / 逃。开局有可逃的弱敌巷战教程。

---

## 5. 最小可玩闭环（已验收）

1. 选出身 → 客栈见退隐刀客「沈孤刃」
2. 「去后巷看看」→ 巷战（可逃）→ 得感悟、开县城
3. 功法图谱花 1 点点亮「起步」
4. 地图朱印旅行触发见面/路遇
5. 自然语言行动 → 结构化推演（意图 / 各方反应 / 数值变化 / 下回合钩子）

`npm run check` 应打印 wanderer loop ok。

---

## 6. 线上部署约定（港机，隔离）

仅在产品方授权且你有 SSH 时使用；**勿动**同机其它业务。

| 项 | 值 |
| --- | --- |
| 主机 | 154.12.21.230 |
| SSH | `ssh -i <key> -p 41017 root@154.12.21.230` |
| 目录 | `/var/www/jianghu-sim` |
| 应用端口 | 3300 |
| 公网 | nginx `3301` → `127.0.0.1:3300` |
| pm2 名 | `jianghu-sim` |
| 禁区 | 勿改 yubangtu / nichecue / newword-radar；勿 reboot；nginx 仅 `nginx -t && nginx -s reload` |

部署机 `.env` 与 `ecosystem.config.cjs` 应 **运行时读 `.env`**，不要把 API Key 写死进 ecosystem。  
公网：http://154.12.21.230:3301

密钥由产品方另行提供；本交接包 **不含** 密钥。

---

## 7. 已知缺口 / 建议下一刀（未要求则先别大改）

- 立绘仍偏 SVG/程序化，可换成统一线稿资产
- 地图是静态卷轴点选，非大战略实时战
- 内容量：据点事件、NPC 私欲、结局线仍薄
- 会话在内存，多实例/重启会丢服务端 session（浏览器 localStorage 可续一部分）
- 尚无独立域名 / HTTPS（若要上，反代到 3301，勿占用其它站点端口）
- 视觉可继续向崇祯参考图靠：羊皮纸纹理、印章分区、更少现代卡片感

---

## 8. 给接手 AI 的工作方式建议

1. 先 `npm install && npm run check && npm run build`，确认本地绿。
2. 改玩法先动 `lib/game/*`，改壳先动 `components/*` + `globals.css`。
3. 战斗平衡只改 `combat.ts` 与目录数据，不要让 LLM 接管判定。
4. 保持「普通人开局」；加掌门线只能作为后期解锁。
5. 任何部署：隔离目录与 pm2 名，验收 `/api/health` 与其它 pm2 进程仍 online。
6. 不要把密钥写入 git、聊天记录或本 HANDOFF。

---

## 9. 包内文件

- `jianghu-sim/` — 完整源码（含 Dockerfile、README、`.env.example`）
- `HANDOFF.md` — 本文件

解压后：

```bash
cd jianghu-sim
cp .env.example .env   # 按需填 Key
npm install
npm run check
npm run dev
```
