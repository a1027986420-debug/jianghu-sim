# 江湖模拟器

普通人从青石渡入江湖。不是掌门，也不是皇帝。会客、赶路、学艺、打架，四件事都能点。

## 本地运行

```bash
npm install
npm run dev
```

打开 `http://127.0.0.1:3300`。

```bash
npm run build
npm start
npm run check
```

`check` 不联网，走一遍：选猎户子、巷战、学会一式、赶到县城。

## 环境变量

见 `.env.example`。不要把真实密钥提交进仓库。

| 变量 | 作用 |
| --- | --- |
| `OPENAI_API_KEY` | 留空则只用本地规则。战斗输赢永远在本地算。 |
| `OPENAI_BASE_URL` | 默认 `https://api.deepseek.com`。请求 `${OPENAI_BASE_URL}/v1/chat/completions`。 |
| `OPENAI_MODEL` | 默认 `deepseek-flash`。`content` 为空时改读 `reasoning_content`。 |
| `PORT` | 默认 `3300`。 |

`GET /api/health` 返回 `ok` 和 `llmConfigured`。

## 页面

- `/` 选出身：猎户子、落魄书生、逃奴、货郎
- `/road` 会客：左立绘、对话、行动草稿
- `/road/map` 山水卷轴，六个朱印据点
- `/road/arts` 身法 / 兵器 / 内息 / 识人
- `/road/fight` 回合战斗

## 战斗

先比身法决定谁先动。命中看兵器、身法对招架。伤害再扣招架和防守。状态有流血、内伤、破防。对手按性格行动：莽夫猛攻，老狐狸防反。喊话只改一两分命中或伤害，不改胜负。模型若在线，只补一句刀风。

## 部署

```bash
docker build -t jianghu .
docker run --rm -p 3300:3300 -e PORT=3300 -e OPENAI_BASE_URL=https://api.deepseek.com -e OPENAI_MODEL=deepseek-flash jianghu
```

或把源码放到 `/var/www/jianghu-sim`，`npm ci && npm run build && PORT=3300 npm start`。会话在进程内存里，公开测试用一个进程。本机 `localStorage` 能续。Cloudflare 只适合把域名指到这台源站，不要当成静态站点丢上 Workers。
