import { connection } from "next/server";
import { applyAction, createWorld } from "@/lib/game/engine";
import { newSessionId, readSession, saveSession } from "@/lib/game/store";
import type { GameAction, WorldState } from "@/lib/game/types";
import type { ApiConfig } from "@/lib/game/llm";

export async function POST(request: Request) {
  await connection();
  const body = (await request.json().catch(() => null)) as {
    sessionId?: unknown;
    world?: unknown;
    action?: unknown;
    apiConfig?: ApiConfig;
  } | null;

  const action = body?.action as GameAction | undefined;

  if (!action || typeof action !== "object" || !("type" in action)) {
    return Response.json({ error: "此项钧令无法辨识。" }, { status: 400 });
  }

  // 读取客户端带来的动态 Key
  const authHeader = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "").trim();
  const apiConfig: ApiConfig = {
    apiKey: authHeader || body?.apiConfig?.apiKey,
    baseUrl: body?.apiConfig?.baseUrl,
    model: body?.apiConfig?.model,
  };

  try {
    if (action.type === "origin") {
      const world = createWorld("landed_gentry");
      const sessionId = newSessionId();
      saveSession(sessionId, world);
      return Response.json({ sessionId, world });
    }

    const requested = typeof body?.sessionId === "string" ? body.sessionId.trim() : "";
    const fromClient = body?.world as WorldState | null;
    const fromServer = requested ? (readSession(requested) as WorldState | null) : null;
    const world = fromClient ?? fromServer;

    if (!world) {
      return Response.json({ error: "案卷已丢失，请重开大局。" }, { status: 400 });
    }

    const next = await applyAction(world, action, apiConfig);
    const sessionId = requested || newSessionId();
    saveSession(sessionId, next);
    return Response.json({ sessionId, world: next });
  } catch (error) {
    const message = error instanceof Error ? error.message : "案台推演受阻。";
    return Response.json({ error: message }, { status: 400 });
  }
}
