import { connection } from "next/server";
import { newSessionId, readSession, saveSession } from "@/lib/game/store";
import type { WorldState } from "@/lib/game/types";

export async function GET(request: Request) {
  await connection();
  const id = new URL(request.url).searchParams.get("id")?.trim();
  if (!id) return Response.json({ error: "缺少会话编号。" }, { status: 400 });
  const stored = readSession(id) as WorldState | null;
  if (!stored) return Response.json({ error: "此局案卷已佚失。" }, { status: 404 });
  return Response.json({ sessionId: id, world: stored });
}

export async function POST(request: Request) {
  await connection();
  const body = (await request.json().catch(() => ({}))) as { sessionId?: unknown; world?: unknown };
  const world = body.world as WorldState | null;
  if (!world || typeof world !== "object") return Response.json({ error: "案卷格式不合。" }, { status: 400 });
  const requested = typeof body.sessionId === "string" ? body.sessionId.trim() : "";
  const sessionId = requested || newSessionId();
  saveSession(sessionId, world);
  return Response.json({ sessionId, world });
}
