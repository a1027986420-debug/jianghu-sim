import { GameProvider } from "@/components/game-provider";
import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "@fontsource/noto-sans-sc/chinese-simplified-400.css";
import "@fontsource/noto-sans-sc/chinese-simplified-700.css";
import "@fontsource/noto-serif-sc/chinese-simplified-600.css";
import "@fontsource/noto-serif-sc/chinese-simplified-700.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "明末枭雄：世家夺鼎录",
  description: "崇祯二年，关中大旱。以落魄世家身份，格物经商、操演部曲，谋夺鼎革。",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#1a1410",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="zh-CN">
      <body>
        <GameProvider>{children}</GameProvider>
      </body>
    </html>
  );
}
