"use client";

import { OriginView } from "@/components/origin-view";
import { STORAGE_KEY } from "@/lib/game/catalog";
import Link from "next/link";
import { useSyncExternalStore } from "react";

function subscribe() {
  return () => {};
}

export default function Page() {
  const saved = useSyncExternalStore(
    subscribe,
    () => Boolean(localStorage.getItem(STORAGE_KEY)),
    () => false,
  );
  return (
    <>
      {saved ? (
        <p className="origin-page">
          <Link className="ink-button" href="/road">
            继续这一趟
          </Link>
        </p>
      ) : null}
      <OriginView />
    </>
  );
}
