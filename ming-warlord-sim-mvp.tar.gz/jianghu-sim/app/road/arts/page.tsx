"use client";

import { ArtsView } from "@/components/arts-view";

export default function Page() {
  return <ArtsView />;
}
