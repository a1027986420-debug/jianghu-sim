"use client";

import { CombatView } from "@/components/combat-view";

export default function Page() {
  return <CombatView />;
}
