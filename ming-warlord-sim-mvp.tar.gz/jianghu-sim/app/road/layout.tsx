import { GameProvider } from "@/components/game-provider";
import { Shell } from "@/components/shell";

export default function RoadLayout({ children }: { children: React.ReactNode }) {
  return (
    <GameProvider>
      <Shell>{children}</Shell>
    </GameProvider>
  );
}
