"use client";

import { ScrollMap } from "@/components/scroll-map";

export default function Page() {
  return <ScrollMap />;
}
