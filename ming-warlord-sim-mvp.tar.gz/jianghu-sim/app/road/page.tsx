"use client";

import { TalkView } from "@/components/talk-view";

export default function Page() {
  return <TalkView />;
}
