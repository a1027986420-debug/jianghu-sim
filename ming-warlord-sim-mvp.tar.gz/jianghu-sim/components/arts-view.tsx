"use client";

import { TECH_CATALOG } from "@/lib/game/catalog";
import type { TechDef } from "@/lib/game/catalog";
import type { TechBranch, TechId } from "@/lib/game/types";
import { useGame } from "@/components/game-provider";

const BRANCHES: { id: TechBranch; label: string; blurb: string }[] = [
  { id: "science", label: "格物致知", blurb: "现代工坊、肥皂、琉璃与火器造粒" },
  { id: "clan", label: "宗族拓殖", blurb: "穿井抗旱、高筑女墙与流民赈济" },
  { id: "military", label: "部曲军略", blurb: "戚家阵法、百步铁铳与重装铁甲" },
  { id: "intrigue", label: "权谋经世", blurb: "公堂周旋、移花接木与暗度陈仓" },
];

export function ArtsView() {
  const { world, busy, send } = useGame();
  if (!world) return null;

  async function learn(techId: TechId) {
    await send({ type: "learn", techId });
  }

  return (
    <section className="scroll-paper-container">
      <div className="arts-header">
        <h2 className="arts-title">关 中 世 家 · 格 物 与 经 世 韬 略 谱</h2>
        <p className="arts-subtitle">
          当前结余经世韬略点：<b className="insight-badge">{world.insight} 点</b>（每旬更迭或大捷可获韬略）
        </p>
      </div>

      <div className="tech-matrix">
        {BRANCHES.map((branch) => {
          const list = TECH_CATALOG.filter((t) => t.branch === branch.id);
          return (
            <div key={branch.id} className="tech-column">
              <div className="branch-header">
                <h3>{branch.label}</h3>
                <small>{branch.blurb}</small>
              </div>

              <div className="nodes-stack">
                {list.map((tech) => {
                  const learned = world.learned.includes(tech.id);
                  const meetsReq = !tech.requires || world.learned.includes(tech.requires);
                  const canLearn = !learned && meetsReq && world.insight >= tech.cost;

                  return (
                    <div
                      key={tech.id}
                      className={`tech-card ${learned ? "learned" : canLearn ? "ready" : "locked"}`}
                    >
                      <div className="tech-card-top">
                        <b className="tech-name">{tech.name}</b>
                        <span className="cost-tag">
                          {learned ? "【已通晓】" : `耗韬略 ${tech.cost} 点`}
                        </span>
                      </div>
                      <p className="tech-desc">{tech.blurb}</p>
                      <p className="tech-effect"><b>效用：</b>{tech.effect}</p>

                      {!learned ? (
                        <button
                          type="button"
                          className="btn-learn-node"
                          disabled={busy || !canLearn}
                          onClick={() => learn(tech.id)}
                        >
                          {canLearn ? "参悟研习" : meetsReq ? "韬略点不足" : "需前置名目"}
                        </button>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
