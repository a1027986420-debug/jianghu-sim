"use client";

import { useGame } from "@/components/game-provider";
import { InkPortrait } from "@/components/ink-figures";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function CombatView() {
  const { world, busy, send } = useGame();
  const router = useRouter();
  const [shout, setShout] = useState("");

  if (!world) return null;
  const combat = world.combat;

  if (!combat) {
    router.push("/road");
    return null;
  }

  const p = combat.player;
  const e = combat.enemy;

  async function act(action: "attack" | "defend" | "art" | "item" | "flee") {
    await send({ type: "combat", action, shout });
    setShout("");
  }

  async function settle() {
    await send({ type: "settle_combat" });
    router.push("/road");
  }

  return (
    <section className="battlefield-container">
      <div className="battle-title-banner">
        <h2>【金戈对垒 · 第 {combat.round} 回合】</h2>
        <span className="battle-type-tag">战阵类型：{combat.encounterType}</span>
      </div>

      <div className="battle-arena">
        <div className="combatant-card player-side">
          <div className="combatant-portrait"><InkPortrait id={p.portrait} /></div>
          <div className="combatant-info">
            <b className="combatant-name">{p.name}</b>
            <div className="bar-wrapper">
              <span>部曲战力: {p.hp} / {p.hpMax}</span>
              <div className="progress-bar"><div className="fill hp" style={{ width: `${(p.hp / p.hpMax) * 100}%` }} /></div>
            </div>
            <div className="bar-wrapper">
              <span>阵型军心: {p.qi} / {p.qiMax}</span>
              <div className="progress-bar"><div className="fill qi" style={{ width: `${(p.qi / p.qiMax) * 100}%` }} /></div>
            </div>
          </div>
        </div>

        <div className="arena-vs">
          <span className="vs-seal">⚔</span>
          <p className="banter-whisper">{combat.banter}</p>
        </div>

        <div className="combatant-card enemy-side">
          <div className="combatant-portrait"><InkPortrait id={e.portrait} /></div>
          <div className="combatant-info">
            <b className="combatant-name">{e.name}</b>
            <div className="bar-wrapper">
              <span>敌阵兵力: {e.hp} / {e.hpMax}</span>
              <div className="progress-bar"><div className="fill hp enemy" style={{ width: `${(e.hp / e.hpMax) * 100}%` }} /></div>
            </div>
          </div>
        </div>
      </div>

      <div className="combat-log-scroll">
        <h4>【战阵交锋实录】</h4>
        <ul className="combat-log-list">
          {combat.log.slice(-6).map((item, idx) => (
            <li key={idx} className="log-entry">❧ {item}</li>
          ))}
        </ul>
      </div>

      {/* 战役结算大卷轴 (替换黑屏) */}
      {combat.over ? (
        <div className="battle-result-paper">
          <h2>{combat.over === "win" ? "【战阵大捷！】" : "【部曲受创！】"}</h2>
          <p className="battle-summary">{combat.rewards?.description}</p>
          <div className="rewards-list">
            {combat.rewards?.silver ? <span className="gain">现银+{combat.rewards.silver} </span> : null}
            {combat.rewards?.grain ? <span className="gain">存粮+{combat.rewards.grain} </span> : null}
            {combat.rewards?.fame ? <span className="gain">声望+{combat.rewards.fame} </span> : null}
          </div>
          <button type="button" className="btn-cinnabar-seal" onClick={settle}>
            清点缴获 · 班师回案台
          </button>
        </div>
      ) : (
        <div className="battle-command-bar">
          <button type="button" className="btn-battle-cmd" disabled={busy} onClick={() => act("attack")}>【斩劈冲锋】</button>
          <button type="button" className="btn-battle-cmd hot" disabled={busy} onClick={() => act("art")}>【战阵杀招】</button>
          <button type="button" className="btn-battle-cmd" disabled={busy} onClick={() => act("defend")}>【结阵防守】</button>
          <button type="button" className="btn-battle-cmd" disabled={busy || world.bandage <= 0} onClick={() => act("item")}>【止血】</button>
          {combat.canFlee ? <button type="button" className="btn-battle-cmd quiet" disabled={busy} onClick={() => act("flee")}>【鸣金撤退】</button> : null}
        </div>
      )}
    </section>
  );
}
