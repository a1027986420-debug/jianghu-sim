"use client";

import { STORAGE_KEY } from "@/lib/game/catalog";
import type { GameAction, WorldState } from "@/lib/game/types";
import { createContext, useContext, useEffect, useState } from "react";

export const API_KEY_STORAGE = "ming_deepseek_api_key";
export const API_MODEL_STORAGE = "ming_deepseek_model";

interface GameContextValue {
  world: WorldState | null;
  sessionId: string | null;
  ready: boolean;
  busy: boolean;
  error: string | null;
  apiKey: string;
  setApiKey: (key: string) => void;
  send: (action: GameAction) => Promise<WorldState | null>;
  clear: () => void;
}

const GameContext = createContext<GameContextValue | null>(null);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [world, setWorld] = useState<WorldState | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [apiKey, setApiKeyState] = useState<string>("");

  useEffect(() => {
    let cancel = false;
    async function boot() {
      try {
        const storedKey = localStorage.getItem(API_KEY_STORAGE) || "";
        if (!cancel) setApiKeyState(storedKey);

        const saved = localStorage.getItem(STORAGE_KEY);
        if (!saved) return;
        const parsed = JSON.parse(saved) as { sessionId?: string; world?: WorldState };
        if (parsed.world?.version !== 3) return;
        const response = await fetch("/api/session", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(parsed),
        });
        const data = (await response.json()) as { sessionId: string; world: WorldState; error?: string };
        if (!response.ok) throw new Error(data.error || "案卷无法续接");
        if (cancel) return;
        setSessionId(data.sessionId);
        setWorld(data.world);
      } catch (caught) {
        if (!cancel) setError(caught instanceof Error ? caught.message : "案卷无法续接");
      } finally {
        if (!cancel) setReady(true);
      }
    }
    void boot();
    return () => {
      cancel = true;
    };
  }, []);

  function setApiKey(key: string) {
    setApiKeyState(key);
    localStorage.setItem(API_KEY_STORAGE, key.trim());
  }

  async function send(action: GameAction) {
    setBusy(true);
    setError(null);
    try {
      const headers: Record<string, string> = { "content-type": "application/json" };
      if (apiKey) {
        headers["authorization"] = `Bearer ${apiKey.trim()}`;
      }

      const response = await fetch("/api/game", {
        method: "POST",
        headers,
        body: JSON.stringify({
          sessionId,
          world,
          action,
          apiConfig: {
            apiKey: apiKey.trim(),
            model: "deepseek-chat",
          },
        }),
      });

      const data = (await response.json()) as { sessionId?: string; world?: WorldState; error?: string };
      if (!response.ok || !data.world || !data.sessionId) throw new Error(data.error || "钧令受阻");
      setSessionId(data.sessionId);
      setWorld(data.world);
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ sessionId: data.sessionId, world: data.world }));
      return data.world;
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "钧令受阻");
      return null;
    } finally {
      setBusy(false);
    }
  }

  function clear() {
    localStorage.removeItem(STORAGE_KEY);
    setWorld(null);
    setSessionId(null);
  }

  return (
    <GameContext.Provider value={{ world, sessionId, ready, busy, error, apiKey, setApiKey, send, clear }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const value = useContext(GameContext);
  if (!value) throw new Error("大案尚未铺开");
  return value;
}
