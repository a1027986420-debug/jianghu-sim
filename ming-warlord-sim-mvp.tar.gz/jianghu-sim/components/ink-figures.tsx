import type { PortraitId } from "@/lib/game/types";

export function InkPortrait({ id, className = "" }: { id: PortraitId; className?: string }) {
  // 预留接口：如果后期放入 public/portraits/[id].png，可优先渲染图片
  // 目前使用高品质水墨意境 SVG 纯代码占位
  return (
    <div className={`ink-figure-wrapper ${className}`} style={{ position: "relative", width: "100%", height: "100%" }}>
      {renderSvgFigure(id)}
    </div>
  );
}

function renderSvgFigure(id: PortraitId) {
  switch (id) {
    case "patriarch": // 陆氏家主：青衫方巾，儒雅中暗藏杀气
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <radialGradient id="inkGlow" cx="50%" cy="40%" r="60%">
              <stop offset="0%" stopColor="#2e261f" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#1a1410" stopOpacity="0" />
            </radialGradient>
          </defs>
          <circle cx="120" cy="140" r="100" fill="url(#inkGlow)" />
          {/* 文生方巾 */}
          <path d="M95 65 L145 65 L140 40 L100 40 Z" fill="#201a16" />
          <path d="M100 40 L120 28 L140 40 Z" fill="#15100d" />
          <rect x="92" y="62" width="56" height="6" fill="#3a2f26" rx="2" />
          {/* 脸部轮廓 (侧影淡墨) */}
          <path d="M105 68 Q120 70 135 68 L138 98 Q120 120 102 98 Z" fill="#dfd1ba" stroke="#2a2018" strokeWidth="2" />
          <path d="M110 88 Q118 92 126 88" stroke="#7a2b27" strokeWidth="2" fill="none" />
          {/* 青衫儒服叠襟 */}
          <path d="M70 120 Q120 95 170 120 L195 310 L45 310 Z" fill="#2d3732" />
          <path d="M120 105 L150 190 L135 310 L105 310 L90 190 Z" fill="#3d4943" stroke="#1d2420" strokeWidth="1.5" />
          <path d="M105 105 L120 160 L135 105" fill="#f4ebd9" stroke="#332820" strokeWidth="2" />
          {/* 暗藏短剑剑柄 */}
          <line x1="75" y1="180" x2="60" y2="225" stroke="#7a2b27" strokeWidth="6" strokeLinecap="round" />
          <circle cx="58" cy="230" r="5" fill="#c49a45" />
        </svg>
      );

    case "accountant": // 老账房：老态龙钟，手捧铜算盘
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          {/* 老年头巾 */}
          <ellipse cx="120" cy="75" rx="32" ry="26" fill="#302820" />
          <path d="M100 78 Q120 80 140 78 L142 108 Q120 124 98 108 Z" fill="#d2c1a6" stroke="#251e17" strokeWidth="2" />
          {/* 白长须 */}
          <path d="M110 98 Q120 145 130 98 Q120 135 110 98 Z" fill="#ece4d4" opacity="0.9" />
          {/* 深褐旧棉袍 */}
          <path d="M60 130 Q120 110 180 130 L190 310 L50 310 Z" fill="#3d3128" />
          {/* 手捧木质算盘 */}
          <rect x="85" y="190" width="70" height="42" fill="#251c14" stroke="#c49a45" strokeWidth="2" rx="2" />
          <line x1="85" y1="204" x2="155" y2="204" stroke="#c49a45" strokeWidth="1" />
          <line x1="100" y1="190" x2="100" y2="232" stroke="#6b5847" strokeWidth="1" />
          <line x1="120" y1="190" x2="120" y2="232" stroke="#6b5847" strokeWidth="1" />
          <line x1="140" y1="190" x2="140" y2="232" stroke="#6b5847" strokeWidth="1" />
        </svg>
      );

    case "officer": // 百户老卒：明军扎甲铁盔，腰挂雁翎刀
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          {/* 铁盔与红缨 */}
          <path d="M92 68 Q120 35 148 68 Z" fill="#2d3339" stroke="#161a1d" strokeWidth="2" />
          <path d="M120 35 L120 15 Q128 20 135 12" stroke="#8e2f2a" strokeWidth="4" strokeLinecap="round" fill="none" />
          <path d="M102 68 Q120 70 138 68 L140 96 Q120 115 100 96 Z" fill="#c9b89f" stroke="#251e17" strokeWidth="2" />
          {/* 刀疤 */}
          <line x1="108" y1="76" x2="116" y2="92" stroke="#6a221e" strokeWidth="1.5" />
          {/* 鱼鳞/山文扎甲 */}
          <path d="M50 115 Q120 95 190 115 L200 310 L40 310 Z" fill="#21272c" />
          <path d="M70 120 L170 120 L160 260 L80 260 Z" fill="#303840" stroke="#8e2f2a" strokeWidth="2" />
          {/* 雁翎刀鞘 */}
          <line x1="60" y1="180" x2="35" y2="290" stroke="#8e2f2a" strokeWidth="8" strokeLinecap="round" />
          <line x1="60" y1="180" x2="68" y2="155" stroke="#c49a45" strokeWidth="6" strokeLinecap="round" />
        </svg>
      );

    case "magistrate": // 知县：七品鸂鶒官袍，乌纱帽，长翅
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          {/* 乌纱帽及两翅 */}
          <ellipse cx="120" cy="58" rx="26" ry="20" fill="#111" />
          <rect x="35" y="55" width="60" height="6" fill="#181818" rx="3" />
          <rect x="145" y="55" width="60" height="6" fill="#181818" rx="3" />
          {/* 面庞 */}
          <path d="M102 65 Q120 67 138 65 L140 98 Q120 118 100 98 Z" fill="#d9caa8" stroke="#251e17" strokeWidth="2" />
          <path d="M108 90 Q120 95 132 90" stroke="#251e17" strokeWidth="2" fill="none" />
          {/* 绿/青色七品官袍与补子 */}
          <path d="M55 115 Q120 95 185 115 L195 310 L45 310 Z" fill="#224233" />
          <rect x="90" y="145" width="60" height="55" fill="#8e2f2a" stroke="#c49a45" strokeWidth="2" />
          {/* 补子飞禽简影 */}
          <path d="M105 175 Q120 155 135 175 Q120 170 105 175 Z" fill="#e6d3a1" />
        </svg>
      );

    case "bandit_boss": // 盗匪头子：袒胸虎皮，横刀
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          {/* 乱发横生 */}
          <circle cx="120" cy="65" r="32" fill="#1a1410" />
          <path d="M92 68 Q120 70 148 68 L145 105 Q120 128 95 105 Z" fill="#aa7d58" stroke="#251e17" strokeWidth="2" />
          <path d="M98 96 Q120 110 142 96" stroke="#111" strokeWidth="4" fill="none" />
          {/* 袒胸皮甲 */}
          <path d="M45 125 Q120 100 195 125 L190 310 L50 310 Z" fill="#4d3319" />
          <path d="M100 115 L140 115 L130 190 L110 190 Z" fill="#aa7d58" />
          {/* 环首宽背厚刀 */}
          <path d="M180 140 L210 280 L195 285 L170 145 Z" fill="#999" stroke="#333" strokeWidth="2" />
          <line x1="170" y1="145" x2="160" y2="120" stroke="#8e2f2a" strokeWidth="7" />
        </svg>
      );

    case "envoy": // 闯军密使：带笠草莽
    default:
      return (
        <svg viewBox="0 0 240 320" className="figure-svg" xmlns="http://www.w3.org/2000/svg">
          {/* 压低的大竹笠 */}
          <path d="M40 75 Q120 30 200 75 L180 85 Q120 50 60 85 Z" fill="#695138" stroke="#332415" strokeWidth="2" />
          {/* 阴影遮面 */}
          <ellipse cx="120" cy="85" rx="30" ry="25" fill="#1b1510" />
          <path d="M110 92 Q120 95 130 92" stroke="#8e2f2a" strokeWidth="2" fill="none" />
          {/* 劲装夜行衣 */}
          <path d="M60 120 Q120 100 180 120 L185 310 L55 310 Z" fill="#1e1b18" />
          <path d="M100 120 L140 120 L135 310 L105 310 Z" fill="#2d2722" />
        </svg>
      );
  }
}
