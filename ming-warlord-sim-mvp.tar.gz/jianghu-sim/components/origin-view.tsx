"use client";

import { useGame } from "@/components/game-provider";
import { InkPortrait } from "@/components/ink-figures";
import { useRouter } from "next/navigation";

export function OriginView() {
  const game = useGame();
  const router = useRouter();

  async function pick() {
    await game.send({ type: "origin", familyName: "陆" });
    router.push("/road");
  }

  return (
    <section className="origin-desk-hero">
      <div className="imperial-decree-scroll">
        <div className="decree-header">
          <div className="imperial-seal-large">明</div>
          <h1 className="decree-title">明 末 枭 雄 · 世 家 夺 鼎 录</h1>
          <p className="decree-time">崇 祯 二 年 · 关 中 大 旱 · 赤 地 千 里</p>
        </div>

        <div className="decree-body">
          <div className="origin-card-highlight">
            <div className="hero-portrait">
              <InkPortrait id="patriarch" />
            </div>
            <div className="hero-dossier">
              <h3>【关中三原 · 陆氏世家】</h3>
              <p className="hero-lead">
                “先父曾中举人，士林留有薄名；祖上蒙朝廷荫庇，握有世袭卫所百户部曲。”
              </p>
              <ul className="hero-traits">
                <li><b>文骨士名：</b>举人门第，知县三班差役明面上敬畏三分，有资格直接上堂奏对。</li>
                <li><b>武备核心：</b>三十名精通雁翎刀、世袭行伍的老卒家丁，效忠陆氏。</li>
                <li><b>格物秘法：</b>胸怀经世巧技（草木灰肥皂、琉璃镜、烧刀子提纯），待时而动。</li>
                <li><b>危机悬顶：</b>大旱歉收，加派辽饷催逼甚急，山贼流寇窥伺坞堡，生死在旦夕之间。</li>
              </ul>
            </div>
          </div>

          <div className="decree-actions">
            <button type="button" className="btn-cinnabar-seal-large" onClick={pick}>
              提 笔 蘸 墨 · 开 案 夺 鼎
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
