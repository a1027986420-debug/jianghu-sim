"use client";

import { useGame } from "@/components/game-provider";
import { PLACES } from "@/lib/game/catalog";
import type { LocationId } from "@/lib/game/types";

// 关中水墨舆图六大据点坐标 (百分比分布)
const MAP_PINS: { id: LocationId; name: string; x: number; y: number; tag: string }[] = [
  { id: "manor", name: "陆氏宗祠·静深书斋", x: 42, y: 55, tag: "家主案台" },
  { id: "workshop", name: "格物作坊·铁冶庐", x: 32, y: 62, tag: "煮皂铸铁" },
  { id: "fort", name: "部曲校场·三合坞堡", x: 48, y: 44, tag: "练兵屯甲" },
  { id: "market", name: "县东草市·流民棚户", x: 60, y: 68, tag: "四方饥民" },
  { id: "yamen", name: "三原县衙·大堂二堂", x: 72, y: 42, tag: "官府三饷" },
  { id: "bandit_camp", name: "黑风寨·牛头岭", x: 22, y: 28, tag: "盘踞马贼" },
];

export function ScrollMap() {
  const { world, busy, send } = useGame();
  if (!world) return null;

  async function travelTo(to: LocationId) {
    await send({ type: "travel", to });
  }

  return (
    <section className="scroll-paper-container">
      <div className="map-header">
        <h2 className="map-title">大 明 陕 西 · 关 中 郡 县 水 墨 舆 图</h2>
        <p className="map-subtitle">渭水横贯，秦岭扼险。指点朱印据点，即可调遣随从亲临巡察。</p>
      </div>

      <div className="historical-map-scroll">
        {/* 背景山水水墨绘制 (SVG) */}
        <svg viewBox="0 0 900 500" className="map-landscape-svg" preserveAspectRatio="none">
          <defs>
            <linearGradient id="parchmentBg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#f3ead7" />
              <stop offset="50%" stopColor="#ebe0c8" />
              <stop offset="100%" stopColor="#dfd0b2" />
            </linearGradient>
          </defs>
          <rect width="900" height="500" fill="url(#parchmentBg)" />

          {/* 秦岭崇山峻岭水墨远山 */}
          <path d="M0 160 Q150 70 300 130 T600 110 T900 140 L900 0 L0 0 Z" fill="#cfc2a8" opacity="0.4" />
          <path d="M0 190 Q180 110 360 170 T720 130 T900 170 L900 0 L0 0 Z" fill="#b9ab91" opacity="0.3" />

          {/* 渭水长河水墨流淌 */}
          <path
            d="M0 380 C200 350, 300 420, 500 380 C700 340, 800 410, 900 370"
            fill="none"
            stroke="#8c998f"
            strokeWidth="14"
            opacity="0.35"
            strokeLinecap="round"
          />
          <text x="420" y="415" fill="#5c6a5f" fontSize="16" letterSpacing="6" fontFamily="serif">渭 水</text>
          <text x="750" y="80" fill="#7a6f5a" fontSize="18" letterSpacing="10" fontFamily="serif">秦 岭 险 隘</text>
        </svg>

        {/* 交互朱印城邑 */}
        {MAP_PINS.map((pin) => {
          const isHere = world.location === pin.id;
          const isUnlocked = world.unlocked.includes(pin.id);

          return (
            <div
              key={pin.id}
              className={`map-seal-pin ${isHere ? "here" : isUnlocked ? "unlocked" : "locked"}`}
              style={{ left: `${pin.x}%`, top: `${pin.y}%` }}
              onClick={() => {
                if (!busy && isUnlocked && !isHere) void travelTo(pin.id);
              }}
            >
              <div className="seal-circle">
                <span className="seal-char">{isHere ? "驻" : "临"}</span>
              </div>
              <div className="seal-label-box">
                <b className="seal-name">{pin.name}</b>
                <span className="seal-tag">{pin.tag}</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
