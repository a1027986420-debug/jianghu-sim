"use client";

import { useGame } from "@/components/game-provider";
import { calendarLabel } from "@/lib/game/catalog";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

const LINKS = [
  { href: "/road", label: "书斋案台" },
  { href: "/road/map", label: "关中舆图" },
  { href: "/road/arts", label: "韬略谱" },
];

export function Shell({ children }: { children: React.ReactNode }) {
  const { world, ready, error, clear, send, apiKey, setApiKey } = useGame();
  const pathname = usePathname();
  const router = useRouter();
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);
  const [keyInput, setKeyInput] = useState("");
  const [saveStatus, setSaveStatus] = useState<string>("");

  useEffect(() => {
    if (ready && !world) router.replace("/");
  }, [ready, world, router]);

  useEffect(() => {
    if (apiKey) setKeyInput(apiKey);
  }, [apiKey]);

  if (!ready || !world) return <p className="paper-note">正在备墨铺开宣纸…</p>;

  const highSuspicion = world.suspicion >= 70;
  const lowGrain = world.grain < 30;

  function handleSaveKey() {
    setApiKey(keyInput.trim());
    setSaveStatus("【朱砂印记】已成功保存在本地浏览器！");
    setTimeout(() => {
      setSaveStatus("");
      setShowApiKeyModal(false);
    }, 1200);
  }

  return (
    <div className="ink-app">
      {/* 顶栏：黑金紫檀案台状态栏 */}
      <header className="ink-bar">
        <div className="ink-bar-left">
          <div className="imperial-seal">明</div>
          <div className="ink-bar-name">
            <b>{world.name} · {world.title}</b>
            <span className="calendar-tag">{calendarLabel(world.year, world.month, world.xun)}</span>
          </div>
        </div>

        {/* 核心治乱指标 */}
        <ul className="ink-stats" aria-label="案台治乱总账">
          <Stat label="族库现银" value={`${world.silver} 两`} />
          <Stat label="庄园存粮" value={`${world.grain} 石`} danger={lowGrain} />
          <Stat label="精锐部曲" value={`${world.troops} 人`} />
          <Stat label="庇护庄民" value={`${world.population} 口`} />
          <Stat label="士林声望" value={`${world.fame}`} />
          <Stat label="官府防备" value={`${world.suspicion}%`} danger={highSuspicion} />
          <Stat label="韬略点" value={`${world.insight}`} />
        </ul>

        <div className="ink-bar-right">
          <button type="button" className="btn-pass-xun" onClick={() => void send({ type: "pass_xun" })}>
            翻至下一旬 ❯
          </button>
          <button
            type="button"
            className="btn-secret-gear"
            onClick={() => {
              setKeyInput(apiKey);
              setShowApiKeyModal(true);
            }}
            title="天机阁密卷（API配置）"
          >
            {apiKey ? "天机密卷 (已接入)" : "天机密卷 (未填Key)"}
          </button>
        </div>
      </header>

      {/* 主体案台布局 */}
      <div className="ink-body">
        <nav className="ink-rail" aria-label="案头签牌">
          {LINKS.map((link) => (
            <Link key={link.href} href={link.href} aria-current={pathname === link.href ? "page" : undefined} className="rail-tab">
              {link.label}
            </Link>
          ))}
          {world.combat ? (
            <Link href="/road/fight" aria-current={pathname === "/road/fight" ? "page" : undefined} className="rail-tab hot">
              金戈阵列
            </Link>
          ) : null}
        </nav>

        <main className="ink-main">
          {error ? <p className="ink-alert" role="alert">{error}</p> : null}
          {world.ending ? <Ending onReset={() => { clear(); router.push("/"); }} /> : children}
        </main>
      </div>

      {/* API 弹窗配置 */}
      {showApiKeyModal ? (
        <div className="modal-mask">
          <div className="modal-paper">
            <h3>【天机阁密卷 · 乾坤灵钥】</h3>
            <p className="modal-tip">
              接入 DeepSeek 官方大模型后，案前 NPC 台词与因果推演将全部由大模型即时推演生成（留空则走本地纯规则）。
            </p>
            <input
              type="password"
              placeholder="请输入您的 DeepSeek API Key (如 sk-...)"
              value={keyInput}
              onChange={(e) => setKeyInput(e.target.value)}
              className="key-input"
            />
            {saveStatus && <p style={{ color: "#2e7d32", fontSize: "0.9rem", margin: "0.3rem 0" }}>{saveStatus}</p>}
            <div className="modal-actions">
              <button type="button" className="btn-cinnabar-seal" onClick={handleSaveKey}>
                朱砂封存
              </button>
              <button type="button" className="btn-ink-seal" onClick={() => setShowApiKeyModal(false)}>
                返回案台
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Stat({ label, value, danger }: { label: string; value: string | number; danger?: boolean }) {
  return (
    <li className={`stat-item ${danger ? "danger" : ""}`}>
      <span className="stat-label">{label}</span>
      <b className="stat-value">{value}</b>
    </li>
  );
}

function Ending({ onReset }: { onReset: () => void }) {
  const { world } = useGame();
  if (!world?.ending) return null;
  const title = {
    executed: "九族遭诛",
    assassinated: "阴谋横死",
    subdued: "俯首降官",
    warlord_triumph: "割据称雄",
    emperor: "龙登九五",
  }[world.ending];

  return (
    <section className="ending-sheet">
      <h1>【{title}】</h1>
      <p>{world.epilogue}</p>
      <button type="button" className="btn-cinnabar-seal" onClick={onReset}>
        重开大局
      </button>
    </section>
  );
}
