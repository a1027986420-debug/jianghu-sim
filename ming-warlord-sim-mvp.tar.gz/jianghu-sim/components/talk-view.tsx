"use client";

import { useGame } from "@/components/game-provider";
import { InkPortrait } from "@/components/ink-figures";
import { placeDef } from "@/lib/game/catalog";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function TalkView() {
  const { world, busy, send } = useGame();
  const router = useRouter();
  const [draft, setDraft] = useState("");
  const [activeTab, setActiveTab] = useState<"clan" | "military" | "diplomacy" | "intrigue">("clan");

  if (!world) return null;
  const npc = world.npcs.find((item) => item.location === world.location) ?? null;
  const place = placeDef(world.location);
  const isExhausted = world.energy <= 0;

  async function speak(kind: "talk" | "act") {
    const text = draft.trim();
    if (!text) return;
    const next = await send(kind === "talk" && npc ? { type: "talk", npcId: npc.id, text } : { type: "act", text, affair: activeTab });
    if (next?.combat) router.push("/road/fight");
    setDraft("");
  }

  async function quickExec(key: string) {
    const next = await send({ type: "affair_exec", key });
    if (next?.combat) router.push("/road/fight");
  }

  return (
    <section className="desk-container">
      <div className="npc-dock">
        <div className="portrait-ink-frame">
          {npc ? <InkPortrait id={npc.portrait} /> : <div className="portrait-empty">案头独坐，四壁萧然</div>}
        </div>
        {npc ? (
          <div className="npc-dossier">
            <h3 className="npc-name">{npc.name}</h3>
            <p className="npc-role-tag">{npc.role}</p>
            <div className="npc-meter">
              <span>信赖/态度：</span>
              <b>{npc.attitude} / 100</b>
            </div>
          </div>
        ) : (
          <div className="npc-dossier">
            <h3 className="npc-name">{place.name}</h3>
            <p className="npc-role-tag">陆氏家主策令之地</p>
          </div>
        )}
      </div>

      <div className="desk-scroll">
        <div className="desk-header">
          <span className="location-badge">当前所处：{place.name}</span>
          <h2 className="desk-title">陆 氏 家 规 策 令 案</h2>
          <span className={`energy-badge ${isExhausted ? "danger" : ""}`}>当旬尚余精力：{world.energy} / {world.energyMax} 刻</span>
        </div>

        {isExhausted && (
          <div className="energy-warning">⚠ 案台精力已耗尽（0/4刻），族人疲惫。请点击右上角【翻至下一旬】重整旗鼓。</div>
        )}

        <div className="dialogue-paper">
          {(npc?.lines ?? [place.blurb]).map((line, idx) => (
            <p key={idx} className="dialogue-line" onClick={() => setDraft(line)}>
              <span className="ink-quill">❧</span> {line}
            </p>
          ))}
        </div>

        {world.slip ? (
          <div className="imperial-slip">
            <div className="slip-tag">【本旬奏报】</div>
            <p><b>钧旨意向：</b>{world.slip.intent}</p>
            <p><b>四方风向：</b>{world.slip.reactions}</p>
            <div className="slip-deltas">
              <b>度支变动：</b>
              {world.slip.deltas.length ? (
                world.slip.deltas.map((d, i) => {
                  const labelMap: Record<string, string> = { silver: "现银", grain: "存粮", troops: "部曲", population: "庄民", fame: "声望", suspicion: "官府猜忌" };
                  return (
                    <span key={i} className={`delta-chip ${d.delta > 0 ? "gain" : "loss"}`}>
                      {labelMap[d.field] ?? d.field} {d.delta > 0 ? "+" : ""}{d.delta} ({d.reason})
                    </span>
                  );
                })
              ) : (
                <span className="delta-chip">此项无银粮折损</span>
              )}
            </div>
            <p className="slip-hook"><b>暗流预警：</b>{world.slip.hook}</p>
          </div>
        ) : null}

        <div className="affair-tabs">
          {["clan", "military", "diplomacy", "intrigue"].map((t) => (
            <button key={t} type="button" className={`affair-tab ${activeTab === t ? "active" : ""}`} onClick={() => setActiveTab(t as any)}>
              {t === "clan" ? "宗族内务" : t === "military" ? "武备团练" : t === "diplomacy" ? "周旋官绅" : "秘谋谍报"}
            </button>
          ))}
        </div>

        <div className="quick-actions-bar">
          {activeTab === "clan" && (
            <>
              <button type="button" className="btn-ink-seal" disabled={busy || isExhausted} onClick={() => quickExec("make_soap")}>
                【煮皂生财】熬制肥皂装箱府城 (+45两现银)
              </button>
              <button type="button" className="btn-ink-seal" disabled={busy || isExhausted} onClick={() => quickExec("relief_grain")}>
                【开仓赈济】施粥收容关中流民 (+40庄民 -15石粮)
              </button>
            </>
          )}
          {activeTab === "military" && (
            <>
              <button type="button" className="btn-ink-seal" disabled={busy || isExhausted} onClick={() => quickExec("drill_troops")}>
                【校场点兵】操演戚家阵法长枪队 (+10精锐部曲 -10两)
              </button>
              <button type="button" className="btn-ink-seal hot" disabled={busy || isExhausted} onClick={() => quickExec("raid_bandits")}>
                【扫荡匪窟】突袭牛头岭黑风寨 (剿匪夺银)
              </button>
            </>
          )}
          {activeTab === "diplomacy" && (
            <>
              <button type="button" className="btn-ink-seal" disabled={busy || isExhausted} onClick={() => setDraft("本举人家世清白，遭关中大旱无从完税，请知县相公体恤减免三饷加派！")}>
                【公堂哭穷】拟抗辩呈文呈递三原知县
              </button>
            </>
          )}
          {activeTab === "intrigue" && (
            <>
              <button type="button" className="btn-ink-seal" disabled={busy || isExhausted} onClick={() => setDraft("密信联络闯军密使，可低价出让一批老酒，借刀拔除邻县霸凌田庄的恶绅。")}>
                【暗通义军】遣死士夜送密信借刀杀人
              </button>
            </>
          )}
        </div>

        <div className="quill-dock">
          <label htmlFor="draft" className="quill-label">【提笔拟批 / 颁布家法钧令】：</label>
          <textarea id="draft" value={draft} maxLength={350} placeholder="在此手书拟定军国大略或应对言辞..." onChange={(e) => setDraft(e.target.value)} className="quill-textarea" />
          <div className="quill-actions">
            <button type="button" className="btn-cinnabar-seal" disabled={busy || !draft.trim() || isExhausted} onClick={() => void speak("act")}>
              {isExhausted ? "精力已尽" : "准奏 · 颁布钧令"}
            </button>
            {npc ? (
              <button type="button" className="btn-ink-seal" disabled={busy || !draft.trim() || isExhausted} onClick={() => void speak("talk")}>
                阶前召对发话
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
