import type { LocationId, PortraitId, Temperament } from "./types";

export interface NpcCanon {
  id: string;
  name: string;
  role: string;
  location: LocationId;
  portrait: PortraitId;
  attitude: number;
  temperament: Temperament;
  privateDesire: string;
  opening: string[];
}

export const NPC_CANON: NpcCanon[] = [
  {
    id: "accountant",
    name: "周升",
    role: "陆氏老账房",
    location: "manor",
    portrait: "accountant",
    attitude: 80,
    temperament: "fox",
    privateDesire: "谨小慎微，生怕少爷行差踏错引来灭顶之灾，一心保全老太爷留下的薄产。",
    opening: [
      "少爷，三原县衙的催饷差役今早又在堡门外晃荡了。",
      "族库现银只剩八十两，若按朝廷加派，下月全家就得典当田产。",
      "听说少爷捣鼓出的那个‘肥皂’极受城中夫人小姐追捧，何不多熬几锅？",
    ],
  },
  {
    id: "officer",
    name: "马元",
    role: "世袭百户老卒 / 护院教头",
    location: "fort",
    portrait: "officer",
    attitude: 75,
    temperament: "brute",
    privateDesire: "卫所溃烂吃不饱饭，只认陆家先太爷恩情，渴望重拾刀枪在乱世干一番大事。",
    opening: [
      "家主！三十个卫所子弟都聚齐了，手里的雁翎刀已磨得吹毛断发。",
      "关中大旱，落草的盗匪多如牛毛。没刀子，再多银子也是替别人存的。",
      "后山的黑风寨屡屡抢劫过路商旅，若家主下令，末将带弟兄们端了它！",
    ],
  },
  {
    id: "magistrate",
    name: "徐敬之",
    role: "三原知县",
    location: "yamen",
    portrait: "magistrate",
    attitude: 35,
    temperament: "fox",
    privateDesire: "背负省城催饷考核，既想从富户身上刮出肥油填补窟窿，又忌惮陆家举人清名。",
    opening: [
      "陆贤侄，令尊在世时与本县交情莫逆。但国事维艰，这辽饷练饷…朝廷催得如催命符。",
      "本县听闻贵堡近来广收四方流民、修筑高墙，这是要做甚？可不要行差踏错。",
      "若拿不出二百两完税，休怪本县依法封庄清丈！",
    ],
  },
  {
    id: "envoy",
    name: "一丈青",
    role: "闯将八大王联络使",
    location: "market",
    portrait: "envoy",
    attitude: 50,
    temperament: "brute",
    privateDesire: "刺探关中世家虚实，试图拉拢地方坞堡提供粮草军械，或趁机破庄劫掠。",
    opening: [
      "陆家少爷，失敬。陕北的弟兄们如今在山里吃糠咽菜，听说陆家庄在蒸馏好酒？",
      "大明朝气数尽了。跟着贪官只有等死，若陆家肯匀出百石军粮，日后闯王进城秋毫无犯。",
      "只要你一句话，牛头岭黑风寨的山匪，我们可以联手做掉。",
    ],
  },
  {
    id: "bandit_boss",
    name: "过天星",
    role: "黑风寨匪首",
    location: "bandit_camp",
    portrait: "bandit_boss",
    attitude: 15,
    temperament: "brute",
    privateDesire: "残暴贪婪，盘踞山隘劫掠关中商道，觊觎陆家庄园的存粮与女眷。",
    opening: [
      "老子不管你爹是什么举人老爷！进了这牛头岭，山神爷最大！",
      "留下五百两过路买路财，外加十车好面，否则老子踏平你那土围子！",
      "弟兄们，抄家伙！给这位细皮嫩肉的书生放放血！",
    ],
  },
];

export function canonOf(id: string): NpcCanon {
  const found = NPC_CANON.find((npc) => npc.id === id);
  if (!found) throw new Error(`查无此人：${id}`);
  return found;
}
