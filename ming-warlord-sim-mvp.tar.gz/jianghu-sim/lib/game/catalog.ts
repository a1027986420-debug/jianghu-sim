import type { LocationId, TechBranch, TechId } from "./types";

export const STORAGE_KEY = "ming_warlord_save_v1";

export interface TechDef {
  id: TechId;
  branch: TechBranch;
  name: string;
  cost: number;
  blurb: string;
  effect: string;
  requires?: TechId;
}

export const TECH_CATALOG: TechDef[] = [
  // 格物致知
  {
    id: "soap",
    branch: "science",
    name: "胰子草木灰皂",
    cost: 1,
    blurb: "取猪胰、草木灰碱液熬煮，芳香去垢。",
    effect: "解锁【肥皂工坊】，每旬可煮皂销往府城，暴赚现银且大增清名。",
  },
  {
    id: "glass",
    branch: "science",
    name: "澄澈琉璃镜",
    cost: 2,
    requires: "soap",
    blurb: "精选石英砂与草木灰提纯，烧制如水晶般通透的玻璃小镜。",
    effect: "可作为贡品行贿抚按大员，大幅降低官府猜忌，或豪卖千金。",
  },
  {
    id: "liquor",
    branch: "science",
    name: "蒸馏烧刀子",
    cost: 2,
    blurb: "天锅蒸馏，出酒烈如刀割。",
    effect: "可清洗金疮箭创减免伤亡；冬日暖军心，部曲战力提升。",
  },
  {
    id: "black_powder",
    branch: "science",
    name: "颗粒军用黑药",
    cost: 3,
    requires: "liquor",
    blurb: "硝、硫、柳炭精准配比，酒润压饼造粒。",
    effect: "火器威能提升50%，破甲与轰鸣震慑大幅增加。",
  },

  // 宗族拓殖
  {
    id: "deep_well",
    branch: "clan",
    name: "关中穿井抗旱",
    cost: 1,
    blurb: "借滑轮深钻打井，取百尺地下甘泉。",
    effect: "庄内良田不受旱灾绝收，秋后保底产粮+50石。",
  },
  {
    id: "granary",
    branch: "clan",
    name: "四方义仓",
    cost: 2,
    requires: "deep_well",
    blurb: "构筑高台透气深仓，开仓设粥厂。",
    effect: "关中流民自发来投，每旬动态涌入人口提升。",
  },
  {
    id: "rampart",
    branch: "clan",
    name: "高垒坞壁女墙",
    cost: 2,
    blurb: "夯土夹碎石筑三丈高壁，建四角望楼矢石备具。",
    effect: "庄园遭袭时，坚固度+40%，可抵御上千盗贼围攻。",
  },
  {
    id: "triage",
    branch: "clan",
    name: "设棚检疫施药",
    cost: 2,
    requires: "granary",
    blurb: "生石灰洒地，煮大锅苍术大黄汤，隔绝关中大疫。",
    effect: "吸纳流民不再引发疫病，庄民存活率大涨。",
  },

  // 部曲军略
  {
    id: "spear_drill",
    branch: "military",
    name: "鸳鸯长枪阵",
    cost: 1,
    blurb: "世袭老卒传授一丈八尺长枪法，前后刺击互保。",
    effect: "部曲破阵伤害提升，对散乱盗匪产生碾压态势。",
  },
  {
    id: "dan_blade",
    branch: "military",
    name: "戚家双手辛酉刀",
    cost: 2,
    requires: "spear_drill",
    blurb: "兼收倭刀之长，势大力沉，专克重甲与轻骑突入。",
    effect: "近身肉搏伤害+25%，可断敌兵刃。",
  },
  {
    id: "three_eye",
    branch: "military",
    name: "百步三眼铁铳",
    cost: 2,
    blurb: "三管熟铁合打，近战可轰散铅子，打空可倒持作铁锤。",
    effect: "战斗中解锁【火铳齐鸣】招式，开局先手重创敌军士气。",
  },
  {
    id: "iron_armor",
    branch: "military",
    name: "锻造山文冷锻甲",
    cost: 3,
    requires: "three_eye",
    blurb: "千锤百炼冷锻铁叶，箭镞难透。",
    effect: "精锐家丁防御大幅翻倍，战死率降低。",
  },

  // 权谋经世
  {
    id: "cry_poor",
    branch: "intrigue",
    name: "公堂悲情哭穷",
    cost: 1,
    blurb: "披麻挂素诉三秦大旱，引圣人训诫抗辩加派三饷。",
    effect: "与知县周旋时，每次可大幅抵扣被勒索的辽饷银两。",
  },
  {
    id: "shift_blame",
    branch: "intrigue",
    name: "移花接木嫁祸",
    cost: 2,
    requires: "cry_poor",
    blurb: "利用文人机锋，将税赋差事转嫁于邻县无良富绅。",
    effect: "可引官府追查敌对士绅，削减自家官府猜忌度。",
  },
  {
    id: "bribe_clerk",
    branch: "intrigue",
    name: "结纳三班衙蠹",
    cost: 2,
    blurb: "酒肉银两暗喂书办与快捕，衙门有风吹草动立得通报。",
    effect: "知县若有抄庄动向，提前3旬预警。",
  },
  {
    id: "rebel_link",
    branch: "intrigue",
    name: "暗度陈仓接流寇",
    cost: 3,
    requires: "bribe_clerk",
    blurb: "通过黑市密商，互不侵犯，借流贼之手拔除眼中钉。",
    effect: "解锁【借刀杀人】，可驱使山贼扫平外围敌对据点。",
  },
];

export function techDef(id: TechId): TechDef {
  const found = TECH_CATALOG.find((tech) => tech.id === id);
  if (!found) throw new Error(`未知名目：${id}`);
  return found;
}

export function hasTech(learned: TechId[], id: TechId): boolean {
  return learned.includes(id);
}

export interface PlaceDef {
  id: LocationId;
  name: string;
  blurb: string;
  danger: boolean;
}

export const PLACES: PlaceDef[] = [
  { id: "manor", name: "陆氏宗祠·静深书斋", blurb: "祖传紫檀书案，陈列关中舆图与族中密账。", danger: false },
  { id: "workshop", name: "格物作坊·铁冶庐", blurb: "烟熏火燎，匠人们在此熬煮肥皂、熔砂铸镜。", danger: false },
  { id: "fort", name: "部曲校场·三合坞堡", blurb: "老百户带队操演枪棒，夯土高墙上插着陆字黑旗。", danger: false },
  { id: "market", name: "县东草市·流民棚户", blurb: "饥民扶老携幼，若施以薄粥，立成死命部曲。", danger: false },
  { id: "yamen", name: "三原县衙·大堂二堂", blurb: "青砖大堂威严赫赫，胥吏手握铁链催缴三饷。", danger: true },
  { id: "bandit_camp", name: "黑风寨·牛头岭", blurb: "盘踞山道的大股马贼，积聚无数粮饷与私铁。", danger: true },
];

export function placeDef(id: LocationId): PlaceDef {
  const found = PLACES.find((place) => place.id === id);
  if (!found) throw new Error(`未知地域：${id}`);
  return found;
}

export function calendarLabel(year: number, month: number, xun: "early" | "mid" | "late"): string {
  const xunStr = { early: "上旬", mid: "中旬", late: "下旬" }[xun];
  const yearName = year === 1629 ? "崇祯二年" : `崇祯${year - 1627}年`;
  return `${yearName} · ${month}月${xunStr}`;
}
