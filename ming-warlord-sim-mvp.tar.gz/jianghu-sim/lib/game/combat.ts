import { canonOf } from "./canon";
import { hasTech } from "./catalog";
import type { CombatAction, CombatState, Fighter, WorldState } from "./types";

export function createCombat(world: WorldState, encounter: "skirmish" | "bandit_raid" | "bailiff_clash"): CombatState {
  const hasDan = hasTech(world.learned, "dan_blade");
  const hasSpear = hasTech(world.learned, "spear_drill");
  const hasArmor = hasTech(world.learned, "iron_armor");

  const player: Fighter = {
    name: `${world.name} (率亲随部曲)`,
    portrait: "patriarch",
    hp: Math.max(30, world.health),
    hpMax: 100,
    qi: 80,
    qiMax: 100,
    parry: 18 + (hasArmor ? 12 : 0),
    agility: 15,
    weapon: 20 + (hasDan ? 8 : 0) + (hasSpear ? 5 : 0),
    bleed: 0,
    internal: 0,
    broken: 0,
    defending: false,
    temperament: "fox",
  };

  let enemy: Fighter;
  if (encounter === "bandit_raid") {
    enemy = {
      name: "黑风寨大当家·过天星",
      portrait: "bandit_boss",
      hp: 120,
      hpMax: 120,
      qi: 70,
      qiMax: 70,
      parry: 15,
      agility: 12,
      weapon: 22,
      bleed: 0,
      internal: 0,
      broken: 0,
      defending: false,
      temperament: "brute",
    };
  } else if (encounter === "bailiff_clash") {
    enemy = {
      name: "三原县衙催粮快班头目",
      portrait: "magistrate",
      hp: 85,
      hpMax: 85,
      qi: 50,
      qiMax: 50,
      parry: 12,
      agility: 14,
      weapon: 18,
      bleed: 0,
      internal: 0,
      broken: 0,
      defending: false,
      temperament: "fox",
    };
  } else {
    enemy = {
      name: "拦路劫道凶悍山贼",
      portrait: "bandit_boss",
      hp: 70,
      hpMax: 70,
      qi: 40,
      qiMax: 40,
      parry: 8,
      agility: 10,
      weapon: 15,
      bleed: 0,
      internal: 0,
      broken: 0,
      defending: false,
      temperament: "brute",
    };
  }

  return {
    id: encounter,
    seed: Date.now(),
    round: 1,
    encounterType: encounter,
    player,
    enemy,
    log: [`双方在牛头岭山道列阵对峙，刀枪林立！第 1 回合请下达战令。`],
    banter: "乱世人命贱如草，手中刀利便称雄！",
    over: null,
    canFlee: encounter !== "bandit_raid",
  };
}

export function playerTurn(
  combat: CombatState,
  action: CombatAction,
  shout: string,
  world: WorldState
): { state: CombatState; bandageUsed?: boolean } {
  let bandageUsed = false;
  const p = combat.player;
  const e = combat.enemy;
  p.defending = false;

  combat.log.push(`────── 【第 ${combat.round} 回合】 ──────`);

  if (action === "flee") {
    combat.log.push(`${p.name}见势不妙，下令部曲鸣金后撤，退守后方坞壁！`);
    combat.over = "flee";
    return { state: combat };
  }

  // 1. 玩家行动结算
  if (action === "item") {
    if (world.bandage > 0) {
      bandageUsed = true;
      p.hp = Math.min(p.hpMax, p.hp + 28);
      combat.log.push(`${p.name}撕开止血布裹扎创口，气血回升 28 点！`);
    } else {
      combat.log.push(`行囊中已无金疮药可用！`);
    }
  } else if (action === "defend") {
    p.defending = true;
    p.parry += 18;
    combat.log.push(`${p.name}命长牌手重甲上前，稳结圆阵严防死守！（本回合受击大幅减免）`);
  } else if (action === "art") {
    const hasThreeEye = hasTech(world.learned, "three_eye");
    const dmg = hasThreeEye ? 36 : 26;
    e.hp = Math.max(0, e.hp - dmg);
    combat.log.push(
      hasThreeEye
        ? `部曲三眼铁铳齐声轰鸣，铅弹暴射如雨，重创${e.name}（破甲杀伤 -${dmg}）！`
        : `精选老卒挺丈八长枪齐步刺杀，狠狠扎进${e.name}前阵（战阵杀伤 -${dmg}）！`
    );
  } else {
    // attack 普通斩击
    const hit = Math.random() > 0.12;
    if (hit) {
      const dmg = Math.max(10, p.weapon - Math.round(e.parry * 0.4));
      e.hp = Math.max(0, e.hp - dmg);
      combat.log.push(`${p.name}拔出雁翎刀疾步劈砍，斫中${e.name}（伤害 -${dmg}）！`);
    } else {
      combat.log.push(`${p.name}挥刀斩击被对方横刀架住！`);
    }
  }

  // 敌方死伤判定
  if (e.hp <= 0) {
    combat.over = "win";
    combat.log.push(`【胜负已分】${e.name}惨呼倒地，贼众阵脚大乱，全线溃败！`);
    return { state: combat, bandageUsed };
  }

  // 2. 敌方反击结算
  const edmg = Math.max(8, e.weapon - (p.defending ? p.parry : Math.round(p.parry * 0.4)));
  p.hp = Math.max(0, p.hp - edmg);
  combat.log.push(`${e.name}面目狰狞，挥动凶顽利刃反扑猛劈，重击我方战线（受损 -${edmg}）！`);

  if (p.defending) p.parry -= 18;

  if (p.hp <= 0) {
    combat.over = "lose";
    combat.log.push(`【力竭战败】我方阵线被破，部曲折损，不得不负伤退却！`);
    return { state: combat, bandageUsed };
  }

  combat.round += 1;
  return { state: combat, bandageUsed };
}
