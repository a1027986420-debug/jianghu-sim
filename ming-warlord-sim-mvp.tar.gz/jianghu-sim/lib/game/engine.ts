import { canonOf } from "./canon";
import { placeDef, techDef } from "./catalog";
import { createCombat, playerTurn } from "./combat";
import { battleBanter, narrateSlip, writeEpilogue } from "./llm";
import type { ApiConfig } from "./llm";
import { ruleSlip } from "./sim";
import { addDelta, clampWorld, considerEnding, createWorld, epilogueFor, npcHere } from "./state";
import type { CombatRewards, CombatState, GameAction, NpcState, Slip, TechId, WorldState } from "./types";

function pushLog(world: WorldState, line: string) {
  world.log = [line, ...world.log].slice(0, 16);
}

function calculateRewards(combat: CombatState): CombatRewards {
  if (combat.over === "win") {
    if (combat.id === "bandit_raid") {
      return {
        silver: 85,
        grain: 50,
        fame: 12,
        suspicionDelta: -8,
        insight: 2,
        description: "斩灭黑风寨匪首过天星，抄获积年脏银八十五两、好面五十石！关中士林交口称颂！",
      };
    } else if (combat.id === "bailiff_clash") {
      return {
        silver: 120,
        grain: 80,
        fame: 20,
        suspicionDelta: -100,
        insight: 3,
        description: "全歼贪婪差吏与省城标营走狗！缴获饷银一百二十两！三原县衙震恐，官府防备瓦解！",
      };
    } else {
      return {
        silver: 30,
        grain: 15,
        fame: 5,
        suspicionDelta: -2,
        insight: 1,
        description: "扫平截道贼寇，缴获白银三十两，部曲威震乡里。",
      };
    }
  } else if (combat.over === "flee") {
    return {
      silver: 0,
      grain: 0,
      fame: -2,
      suspicionDelta: 0,
      insight: 0,
      description: "鸣金后撤，保存主力退守高垒，部曲声威略受损伤。",
    };
  } else {
    return {
      silver: 0,
      grain: 0,
      fame: -6,
      suspicionDelta: 5,
      insight: 0,
      description: "我军阵线受挫，折损数名精锐部曲，族中门楣受辱。",
    };
  }
}

function settleCombat(world: WorldState, combat: CombatState) {
  const lost = combat.player.hpMax - Math.max(0, combat.player.hp);
  world.health -= Math.round(lost * 0.35);

  const rew = combat.rewards ?? calculateRewards(combat);
  world.silver += rew.silver;
  world.grain += rew.grain;
  world.fame = Math.min(100, Math.max(0, world.fame + rew.fame));
  world.suspicion = Math.min(100, Math.max(0, world.suspicion + rew.suspicionDelta));
  world.insight += rew.insight;

  if (combat.over === "win") {
    if (combat.id === "bandit_raid") {
      world.flags.banditCampDown = true;
    } else if (combat.id === "bailiff_clash") {
      world.flags.countySubdued = true;
      world.title = "关中团练防寇使";
    }
    pushLog(world, `大捷：${rew.description}`);
  } else if (combat.over === "lose") {
    world.health -= 15;
    world.troops = Math.max(5, world.troops - 6);
    pushLog(world, `败阵：${rew.description}`);
  }

  world.report = combat.log.slice(-24);
  world.combat = null;
  world.turn += 1;
  clampWorld(world);
  considerEnding(world);
}

function applySlip(world: WorldState, npc: NpcState | null, slip: Slip, lines?: string[], bandage?: number) {
  for (const delta of slip.deltas) addDelta(world, delta.field, delta.delta);
  if (bandage) world.bandage += bandage;
  if (npc && lines && lines.length) npc.lines = lines;
  world.slip = slip;
  world.turn += 1;
  world.energy = Math.max(0, world.energy - 1);
  clampWorld(world);
  considerEnding(world);
}

export function passXun(world: WorldState): string {
  world.energy = world.energyMax;
  if (world.xun === "early") {
    world.xun = "mid";
  } else if (world.xun === "mid") {
    world.xun = "late";
  } else {
    world.xun = "early";
    world.month += 1;
    if (world.month > 12) {
      world.month = 1;
      world.year += 1;
    }
    const grainConsumed = Math.round(world.troops * 0.25 + world.population * 0.08);
    world.grain = Math.max(0, world.grain - grainConsumed);
    world.silver += 5;
    world.insight += 1;
  }

  let desc = `历法更迭至${world.year}年${world.month}月${{ early: "上旬", mid: "中旬", late: "下旬" }[world.xun]}。时辰精力已回满（4刻）。`;

  if (world.suspicion >= 100) {
    world.combat = createCombat(world, "bailiff_clash");
    desc += " ⚠ 警报：三原知县勾结按察使标营，以私藏军械、聚啸流民之罪，率缇骑重兵破门抄庄！生死一战不可避免！";
  }

  pushLog(world, desc);
  return desc;
}

export async function applyAction(
  world: WorldState,
  action: GameAction,
  apiConfig?: ApiConfig
): Promise<WorldState> {
  if (world.ending && action.type !== "origin") throw new Error("此局已定。");

  if (action.type === "origin") {
    return createWorld("landed_gentry");
  }

  if (action.type === "ending") {
    considerEnding(world, action.ending);
    return world;
  }

  if (world.combat && !world.combat.over && action.type !== "combat") {
    throw new Error("金戈铁马在眼前，先把眼前阵仗打完！");
  }

  if (action.type === "settle_combat") {
    if (!world.combat || !world.combat.over) throw new Error("阵仗尚未决出胜负。");
    settleCombat(world, world.combat);
    return world;
  }

  if (action.type === "pass_xun") {
    const text = passXun(world);
    world.slip = {
      intent: "掩卷沉思，翻阅下一旬关中邸报。",
      reactions: text,
      deltas: [],
      hook: world.suspicion >= 100 ? "官军已临城下，唯死战以求生机！" : "新一旬到来，族人正待家主开案布令。",
      source: "rule",
    };
    return world;
  }

  if (action.type === "learn") {
    if (world.learned.includes(action.techId)) throw new Error("此韬略早已了然于胸。");
    const tech = techDef(action.techId);
    if (world.insight < tech.cost) throw new Error("经世韬略点不足，尚需历练。");
    world.insight -= tech.cost;
    world.learned.push(action.techId);
    if (action.techId === "soap" && !world.unlocked.includes("workshop")) world.unlocked.push("workshop");
    if (action.techId === "spear_drill" && !world.unlocked.includes("fort")) world.unlocked.push("fort");
    world.slip = {
      intent: `家主闭门精研【${tech.name}】。`,
      reactions: tech.blurb + " " + tech.effect,
      deltas: [],
      hook: "韬略既成，可在案台或各处工坊施展。",
      source: "rule",
    };
    return world;
  }

  if (action.type === "travel") {
    world.location = action.to;
    if (action.to === "workshop" && !world.unlocked.includes("workshop")) world.unlocked.push("workshop");
    if (action.to === "fort" && !world.unlocked.includes("fort")) world.unlocked.push("fort");
    if (action.to === "yamen" && !world.unlocked.includes("yamen")) world.unlocked.push("yamen");
    if (action.to === "bandit_camp" && !world.unlocked.includes("bandit_camp")) world.unlocked.push("bandit_camp");
    const npc = npcHere(world);
    world.slip = {
      intent: `移驾至【${placeDef(action.to).name}】。`,
      reactions: placeDef(action.to).blurb,
      deltas: [],
      hook: npc ? `${npc.name}（${npc.role}）正在阶前伺候。` : "四壁井然，静候钧令。",
      source: "rule",
    };
    return world;
  }

  if (action.type === "start-fight") {
    if (world.energy <= 0) throw new Error("当旬时辰精力已耗尽（0/4刻），请先点击右上角【翻至下一旬】！");
    world.combat = createCombat(world, action.encounter);
    world.turn += 1;
    world.energy = Math.max(0, world.energy - 1);
    return world;
  }

  if (action.type === "combat") {
    if (!world.combat || world.combat.over) throw new Error("当下并无仗要打。");
    const stepped = playerTurn(world.combat, action.action, action.shout ?? "", world);
    if (stepped.bandageUsed) world.bandage = Math.max(0, world.bandage - 1);
    world.combat = stepped.state;
    const fact = world.combat.log.at(-1) ?? "";
    const banter = await battleBanter(world.combat, fact, apiConfig);
    if (banter) world.combat.banter = banter;

    if (world.combat.over) {
      world.combat.rewards = calculateRewards(world.combat);
    }
    return world;
  }

  // 精力判定拦截
  if (world.energy <= 0) {
    throw new Error("当旬时辰精力已尽（0/4刻），族人家丁皆已疲乏。请翻至下一旬以启新政！");
  }

  let promptText = "";
  let affair = action.type === "act" ? action.affair : undefined;

  if (action.type === "affair_exec") {
    if (action.key === "make_soap") promptText = "家主下令：工坊老匠人加速熬制草木灰肥皂，装箱销往府城顾家大户。";
    else if (action.key === "relief_grain") promptText = "家主下令：庄园开仓架大锅布施稠粥，妥善收容安置四方逃难而来的关中流民。";
    else if (action.key === "drill_troops") promptText = "家主下令：校场百户部曲集合操演戚家阵法长枪排阵，检阅家丁武备。";
    else if (action.key === "raid_bandits") {
      world.combat = createCombat(world, "bandit_raid");
      world.energy = Math.max(0, world.energy - 1);
      return world;
    }
  } else {
    promptText = action.text.trim();
  }

  if (!promptText) throw new Error("案头不可无言。");
  const npc = action.type === "talk" ? world.npcs.find((n) => n.id === action.npcId) ?? null : npcHere(world);

  // 1. 本地硬规则做保底（防止 AI 宕机或无 Key 时完全不能玩）
  const ruled = ruleSlip(world, promptText, npc, affair);
  let slip = ruled.slip;
  let lines = ruled.lines;

  // 2. 核心大模型真推演（如果用户提供了 Key 或配置了模型）
  const model = await narrateSlip(world, promptText, npc?.id, apiConfig);
  if (model) {
    slip = model;
    if (model.lines?.length) lines = model.lines;
  }

  if (npc) {
    npc.attitude = Math.min(100, Math.max(0, npc.attitude + ruled.attitude));
  }

  applySlip(world, npc, slip, lines, ruled.bandage);
  return world;
}

export { createWorld };
