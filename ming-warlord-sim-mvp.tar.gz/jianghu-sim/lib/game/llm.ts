import { NPC_CANON } from "./canon";
import { epilogueFor } from "./state";
import type { CombatState, EndingId, Slip, WorldState } from "./types";

export interface ApiConfig {
  apiKey?: string;
  baseUrl?: string;
  model?: string;
}

interface ChatMessage {
  content?: unknown;
  reasoning_content?: unknown;
}

export function chatCompletionsUrl(base: string): string {
  const trimmed = base.trim().replace(/\/+$/, "");
  if (trimmed.endsWith("/v1")) return `${trimmed}/chat/completions`;
  return `${trimmed}/v1/chat/completions`;
}

export function messageText(message: ChatMessage | null | undefined): string {
  const content = contentToString(message?.content).trim();
  if (content) return content;
  return contentToString(message?.reasoning_content).trim();
}

function contentToString(value: unknown): string {
  if (typeof value === "string") return value;
  if (!Array.isArray(value)) return "";
  return value
    .map((part) => {
      if (typeof part === "string") return part;
      if (part && typeof part === "object" && "text" in part && typeof part.text === "string") return part.text;
      return "";
    })
    .join("");
}

export function extractJsonObject(text: string): Record<string, unknown> | null {
  const trimmed = text.trim();
  const direct = asRecord(tryParse(trimmed));
  if (direct) return direct;
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) {
    const fenced = asRecord(tryParse(fence[1]));
    if (fenced) return fenced;
  }
  let from = trimmed.lastIndexOf("{");
  while (from >= 0) {
    const end = trimmed.lastIndexOf("}");
    if (end > from) {
      const parsed = asRecord(tryParse(trimmed.slice(from, end + 1)));
      if (parsed && typeof parsed.intent === "string") return parsed;
    }
    from = trimmed.lastIndexOf("{", from - 1);
  }
  return null;
}

function tryParse(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

export async function complete(
  messages: { role: string; content: string }[],
  maxTokens = 900,
  config?: ApiConfig
): Promise<string | null> {
  const key = config?.apiKey?.trim() || process.env.OPENAI_API_KEY?.trim();
  if (!key) return null;

  const base = config?.baseUrl?.trim() || process.env.OPENAI_BASE_URL?.trim() || "https://api.deepseek.com";
  const url = chatCompletionsUrl(base);
  const model = config?.model?.trim() || process.env.OPENAI_MODEL?.trim() || "deepseek-chat";

  const attempts: Record<string, unknown>[] = [
    { response_format: { type: "json_object" }, temperature: 0.7 },
    { temperature: 0.7 },
    {},
  ];

  for (const extra of attempts) {
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
        body: JSON.stringify({ model, messages, max_tokens: maxTokens, ...extra }),
        signal: AbortSignal.timeout(25000),
      });
      if (response.status === 400) continue;
      if (!response.ok) {
        console.error("DeepSeek API 请求失败:", response.status, await response.text().catch(() => ""));
        return null;
      }
      const payload = (await response.json()) as { choices?: { message?: ChatMessage }[] };
      const text = messageText(payload.choices?.[0]?.message);
      if (text) return text;
    } catch (err) {
      console.error("DeepSeek 请求异常:", err);
      return null;
    }
  }
  return null;
}

const FIELDS = new Set(["silver", "grain", "troops", "population", "fame", "suspicion"]);
const CAP: Record<string, number> = { silver: 120, grain: 100, troops: 40, population: 150, fame: 20, suspicion: 25 };

export function slipFromModel(parsed: Record<string, unknown>): Slip | null {
  const intent = typeof parsed.intent === "string" ? parsed.intent.trim().slice(0, 200) : "";
  const reactions = typeof parsed.reactions === "string" ? parsed.reactions.trim().slice(0, 350) : "";
  const hook = typeof parsed.hook === "string" ? parsed.hook.trim().slice(0, 180) : "";
  if (!intent || !reactions || !hook) return null;
  if (!Array.isArray(parsed.deltas)) return null;

  const deltas: Slip["deltas"] = [];
  for (const item of parsed.deltas) {
    if (!item || typeof item !== "object") continue;
    const record = item as Record<string, unknown>;
    const field = typeof record.field === "string" ? record.field : "";
    const delta = typeof record.delta === "number" ? Math.round(record.delta) : NaN;
    const reason = typeof record.reason === "string" ? record.reason.trim() : "";
    if (!FIELDS.has(field) || !Number.isInteger(delta) || delta === 0) continue;
    if (Math.abs(delta) > (CAP[field] ?? 0) || reason.length < 2) continue;
    deltas.push({ field: field as Slip["deltas"][number]["field"], delta, reason: reason.slice(0, 50) });
  }

  const lines = Array.isArray(parsed.lines)
    ? parsed.lines.filter((line): line is string => typeof line === "string").map((line) => line.slice(0, 120)).slice(0, 3)
    : [];

  return {
    intent,
    reactions,
    deltas,
    hook,
    source: "llm",
    ...(lines.length ? { lines } : {}),
  } as Slip & { lines?: string[] };
}

export async function narrateSlip(
  world: WorldState,
  text: string,
  npcId?: string,
  config?: ApiConfig
): Promise<(Slip & { lines?: string[] }) | null> {
  const key = config?.apiKey?.trim() || process.env.OPENAI_API_KEY?.trim();
  if (!key) return null;

  const npc = NPC_CANON.find((item) => item.id === npcId);
  const prompt = [
    "【最高指示】：你是一个拥有硬核历史厚重感、深谙明末官绅勾结与乱世生存的 AI 游戏推演中枢。请根据玩家的家主政令进行具有真实历史感与戏剧张力的推演，必须且只输出严格的 JSON。",
    "",
    "【时代与地缘背景】：",
    "崇祯二年（1629年），陕西关中大旱，赤地千里，流民如蚁。朝廷三饷（辽饷、剿饷、练饷）加派如催命符，官逼民反。李自成、张献忠正在邻近陕北蠢蠢欲动。",
    "",
    "【主角家世】：",
    `关中三原落魄世家家主 ${world.name}（${world.title}）。先父为已故举人，士林留有文名；家族暗中握有一支世袭卫所百户部曲军户，通晓戚家刀法与现代格物技术（肥皂、琉璃、烧酒提纯）。`,
    `当前家族账本：族库现银 ${world.silver} 两，庄园存粮 ${world.grain} 石，精锐家丁部曲 ${world.troops} 人，庇护避难庄民 ${world.population} 口，士林声望 ${world.fame}/100，官府防备 ${world.suspicion}%。`,
    "",
    npc
      ? `【当前案前对坐交涉者】：${npc.name}（身份：${npc.role}，性格偏向：${npc.temperament}）。其内心深处不可告人的私心是：${npc.privateDesire}。台词不可直接直白念出此私心，应体现老谋深算的话术博弈。`
      : "【当前场景】：静深书斋案头独坐，提笔向家族各管事、工坊、校场发出书面钧令。",
    "",
    `【玩家下达的家主言行/政令草稿】：`,
    `"${text}"`,
    "",
    "【输出规范要求】：",
    "你必须根据玩家的具体言行，推演出充满意外变数与历史质感的生动剧情，并输出 JSON：",
    "1. intent (string): 家主此番言行的真实战略意图概括（约20-40字）。",
    "2. reactions (string): 四方各界反应与生动剧情描写。例如对方的微妙微表情、官府暗探的窥视、商贾的追捧或饥民的感激，展现明末活生生的人间百态（约60-120字）。",
    "3. lines (string[]): 对方在听完后说出的 1~2 句充满明代官场白话或市井韵味的直接台词。",
    "4. deltas (array): 必须体现因果报应的度支数值波动！每个对象包含 field, delta, reason。field 仅限于：",
    "   - 'silver': 现银变动（正负均可，如经商进账+40~80，赏赐家丁-10~20）",
    "   - 'grain': 存粮变动（如开仓赈济-10~30，秋粮入仓+20~50）",
    "   - 'troops': 精锐部曲（如招募家丁+5~15）",
    "   - 'population': 庇护流民人口（如招徕饥民+20~60）",
    "   - 'fame': 士林清望声名（范围-15 ~ +15）",
    "   - 'suspicion': 官府猜忌防备（范围-15 ~ +20，违抗王法或大举练兵会增加，行贿哭穷会减少）",
    "5. hook (string): 局势随后的暗流暗涌与给玩家的决策悬念（约20-40字）。",
  ].join("\n");

  const textOut = await complete(
    [
      { role: "system", content: "你是一个历史严肃风格的世家争霸推演 AI，精通明代官话与世情，严格输出合法 JSON。" },
      { role: "user", content: prompt },
    ],
    900,
    config
  );

  const parsed = textOut ? extractJsonObject(textOut) : null;
  return parsed ? slipFromModel(parsed) : null;
}

export async function battleBanter(state: CombatState, fact: string, config?: ApiConfig): Promise<string | null> {
  const text = await complete(
    [
      {
        role: "system",
        content: "写一句明末沙场短兵相接的短促喊话或刀剑金铁交鸣声。不超过30字，不输出数字和胜负，不加引号，不要 JSON。",
      },
      {
        role: "user",
        content: `战事交锋事实：${fact}。${state.player.name}与${state.enemy.name}对决。`,
      },
    ],
    120,
    config
  );
  const line = text?.replace(/```/g, "").trim();
  if (!line || /\d{2,}/.test(line)) return null;
  return line.slice(0, 30);
}

export async function writeEpilogue(world: WorldState, ending: EndingId, config?: ApiConfig): Promise<string> {
  const fallback = epilogueFor({ ...world, ending });
  const text = await complete(
    [
      { role: "system", content: "写一段崇祯末年世家兴衰终局，文言典雅，两三句，不加新剧情，不要 JSON。" },
      {
        role: "user",
        content: `结局：${ending}。陆氏家主${world.name}，部曲${world.troops}，存银${world.silver}，庇护流民${world.population}口，声望${world.fame}。`,
      },
    ],
    280,
    config
  );
  const prose = text?.replace(/```/g, "").trim();
  if (!prose || prose.length < 12) return fallback;
  return prose.slice(0, 400);
}
