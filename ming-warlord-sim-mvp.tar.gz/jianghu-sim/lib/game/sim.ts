import { canonOf } from "./canon";
import { hasTech } from "./catalog";
import type { Delta, NpcState, Slip, WorldState } from "./types";

function quote(text: string) {
  return `「${text.replace(/\s+/g, "").slice(0, 36)}」`;
}

export function ruleSlip(
  world: WorldState,
  text: string,
  npc: NpcState | null,
  affair?: "clan" | "military" | "diplomacy" | "intrigue"
): { slip: Slip; attitude: number; lines: string[]; bandage?: number } {
  const deltas: Delta[] = [];
  let attitude = 0;
  let bandage: number | undefined;

  let lines = ["对方沉吟片刻，目光深邃，未将话说满。"];
  let reactions = "话音落在紫檀书案间，烛火微晃，各方心思暗涌。";
  let hook = "案头文书未结，尚待家主定夺。";

  // 1. 格物致知 / 经商生财 (肥皂 / 琉璃 / 烧酒)
  if (/肥皂|胰子|熬皂|工坊|卖皂/.test(text)) {
    const hasSoap = hasTech(world.learned, "soap");
    if (hasSoap || world.location === "workshop") {
      deltas.push({ field: "silver", delta: 45, reason: "工坊出皂，倾销府城富室" });
      deltas.push({ field: "fame", delta: 4, reason: "去污奇物轰动关中士林" });
      attitude = 6;
      lines = ["周升拨动算盘珠子，老脸笑开了花：“少爷，这胰子皂真乃生财神物！省城顾家一口气定了二十箱！”"];
      reactions = "现银如流水般注入族库，陆氏一族生计立时稳固。";
      hook = "银两充足，可扩充部曲或开仓收容流民。";
    } else {
      lines = ["工坊老匠人无奈拱手：“家主，咱们尚不知草木灰与油脂精准火候，需先参悟格物之法。”"];
      reactions = "未通格物，暂难成事。";
      hook = "可先在韬略谱中点亮【胰子草木灰皂】。";
    }
  }

  // 2. 开仓赈济 / 吸纳流民
  else if (/施粥|赈济|收容|流民|开仓|分粮/.test(text)) {
    if (world.grain >= 15) {
      deltas.push({ field: "grain", delta: -15, reason: "开仓架锅，布施稠粥" });
      deltas.push({ field: "population", delta: 40, reason: "四方饥民扶老携幼入庄投效" });
      deltas.push({ field: "fame", delta: 6, reason: "关中士林盛赞陆家仁义" });
      deltas.push({ field: "suspicion", delta: 4, reason: "坞堡人口渐增引来县衙注视" });
      attitude = 8;
      lines = ["饥民伏地痛哭叩首：“谢陆老爷活命之恩！愿世世代代为陆家做牛做马！”"];
      reactions = "饥民感念活命大恩，坞堡人口大增，开荒与筑墙劳力充沛。";
      hook = "有了青壮人口，可挑出身强体健者编入部曲。";
    } else {
      lines = ["周升护住粮仓钥匙直跺脚：“少爷！族里存粮见底了，再分下去自家家丁都要饿肚子了！”"];
      reactions = "仓中无粟，难以赈民。";
      hook = "需先筹银购粮，或穿井抗旱保全秋粮。";
    }
  }

  // 3. 操演部曲 / 备战
  else if (/练兵|操演|校场|阵法|百户|部曲/.test(text)) {
    if (world.silver >= 10) {
      deltas.push({ field: "silver", delta: -10, reason: "犒赏卫所子弟与发放肉食" });
      deltas.push({ field: "troops", delta: 10, reason: "收拢健壮流民，精选编入部曲" });
      deltas.push({ field: "suspicion", delta: 5, reason: "校场杀声震天，引起密探注意" });
      attitude = 10;
      lines = ["马元抱拳厉声应诺：“家主放心！属下按戚少保纪效新书操演，三十步内枪出如龙！”"];
      reactions = "陆家部曲锐气大涨，隐隐已有正规边军精锐之气象。";
      hook = "兵马已备，可出山扫平黑风寨匪患。";
    } else {
      lines = ["马元长叹一声：“弟兄们刀口舔血，光靠两句空话练不出精兵，好歹得有点肉腥饷银啊。”"];
      reactions = "饷银不足，军心稍显涣散。";
      hook = "先设法赚取银两犒赏军心。";
    }
  }

  // 4. 周旋县衙 / 哭穷抗税
  else if (/加派|三饷|辽饷|哭穷|免赋|税银/.test(text) && world.location === "yamen") {
    const hasCryPoor = hasTech(world.learned, "cry_poor");
    if (hasCryPoor) {
      deltas.push({ field: "silver", delta: -15, reason: "巧言哭穷，仅纳象征性赋税" });
      deltas.push({ field: "suspicion", delta: -10, reason: "知县信以为真，戒心暂缓" });
      attitude = 5;
      lines = [
        "徐知县揉着眉心长叹：“令尊清贫高洁，陆家遭灾亦苦……也罢，本县且将你家除名大户，先交十五两应付省城吧。”",
      ];
      reactions = "凭借世家机锋与圣人大义，硬生生顶回了贪婪差吏的敲诈。";
      hook = "官府猜忌降低，换来数月潜心蓄势之机。";
    } else {
      deltas.push({ field: "silver", delta: -50, reason: "无从辩驳，被迫交纳巨额辽饷" });
      deltas.push({ field: "fame", delta: -2, reason: "官府得寸进尺，乡人暗叹弱势" });
      attitude = -5;
      lines = ["徐知县把官印一拍：“皇粮国税，岂同儿戏！三日内若凑不齐五十两，本县拿你去二堂问话！”"];
      reactions = "白花花的现银被官府掠走，族人敢怒不敢言。";
      hook = "隐忍难长久，当思变局之策。";
    }
  }

  // 5. 违和荒谬言论（现代梗/胡闹言行）-> 触发硬核严厉惩处
  else if (/冲锋枪|外星人|奥特曼|飞机|火箭|导弹|民主/.test(text)) {
    deltas.push({ field: "fame", delta: -8, reason: "胡言乱语，士林疑其患离魂疯症" });
    deltas.push({ field: "suspicion", delta: 12, reason: "言行悖逆妖邪，引起官府缇骑疑虑" });
    lines = [
      "众人面面相觑，面露惶恐之色。",
      "老账房吓得扑通跪地：“少爷！慎言啊！这等妖异悖谬之语若传到按察使耳里，可是要招来锦衣卫锁拿问罪的！”",
    ];
    reactions = "四周仆从战栗噤声，官绅疑惧，陆氏清名大受损伤。";
    hook = "在明末乱世，慎言慎行方能保全九族。";
  }

  // 6. 常规应答
  else {
    attitude = 2;
    lines = npc ? [`${npc.name}躬身听命。`, npc.lines[0] ?? "全凭少爷吩咐。"] : ["书斋内书童换上一巡新茶，静候钧旨。"];
    reactions = npc ? `${npc.name}唯唯诺诺，揣摩着家主意图。` : "四壁萧然，唯舆图明暗未定。";
    hook = "可翻阅案头折子，或移步各处工坊校场巡视。";
  }

  const slip: Slip = {
    intent: `家主立下钧旨${quote(text)}。`,
    reactions,
    deltas,
    hook,
    source: "rule",
  };
  return { slip, attitude, lines, bandage };
}
