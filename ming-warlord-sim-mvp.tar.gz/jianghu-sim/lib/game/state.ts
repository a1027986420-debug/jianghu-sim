import { NPC_CANON } from "./canon";
import { TECH_CATALOG } from "./catalog";
import type { WorldState } from "./types";

export function createWorld(origin: "landed_gentry" | "fallen_soldier" | "scholar_heir"): WorldState {
  const world: WorldState = {
    version: 3,
    stage: "recluse",
    title: "关中乡绅",
    name: "陆怀远",
    year: 1629,
    month: 4,
    xun: "early",
    energy: 4,
    energyMax: 4,
    turn: 0,
    
    // 初始经济与人口设置
    silver: 80,
    grain: 120,
    troops: 25,
    population: 150,
    fame: 30,
    suspicion: 10,
    
    insight: 2,
    health: 90,
    bandage: 2,
    
    location: "manor",
    unlocked: ["manor", "workshop"],
    learned: [],
    
    npcs: NPC_CANON.map((c) => ({
      id: c.id,
      name: c.name,
      role: c.role,
      location: c.location,
      attitude: c.attitude,
      portrait: c.portrait,
      lines: [...c.opening],
    })),
    combat: null,
    slip: null,
    report: [],
    log: ["崇祯二年春，关中大旱，赤地千里。", "祖上传下的陆氏坞堡，正面临赋税催逼。"],
    ending: null,
    epilogue: null,
    flags: { alley: "open" },
  };
  return world;
}

export function addDelta(world: WorldState, field: "silver" | "grain" | "troops" | "population" | "fame" | "suspicion", delta: number) {
  if (field === "silver") world.silver += delta;
  else if (field === "grain") world.grain += delta;
  else if (field === "troops") world.troops += delta;
  else if (field === "population") world.population += delta;
  else if (field === "fame") world.fame = Math.min(100, Math.max(0, world.fame + delta));
  else if (field === "suspicion") world.suspicion = Math.min(100, Math.max(0, world.suspicion + delta));
}

export function clampWorld(world: WorldState) {
  world.silver = Math.max(0, world.silver);
  world.grain = Math.max(0, world.grain);
  world.troops = Math.max(0, world.troops);
  world.population = Math.max(0, world.population);
  world.health = Math.min(100, Math.max(0, world.health));
}

export function epilogueFor(world: WorldState): string {
  if (world.ending === "executed") return "家破人亡，陆氏传承断绝。";
  return "不知归处。";
}

export function considerEnding(world: WorldState, ending?: "executed" | "assassinated" | "subdued" | "warlord_triumph" | "emperor") {
  if (world.health <= 0) world.ending = "executed";
  if (ending) world.ending = ending;
}

export function npcHere(world: WorldState) {
  return world.npcs.find((n) => n.location === world.location) || null;
}
