import type { WorldState } from "./types";

interface Bucket {
  map: Map<string, string>;
  order: string[];
}

const KEY = "__jianghuWanderV2";

function bucket(): Bucket {
  const root = globalThis as typeof globalThis & { [KEY]?: Bucket };
  if (!root[KEY]) root[KEY] = { map: new Map(), order: [] };
  return root[KEY];
}

export function saveSession(id: string, world: WorldState) {
  const sessions = bucket();
  if (!sessions.map.has(id)) sessions.order.push(id);
  sessions.map.set(id, JSON.stringify(world));
  while (sessions.order.length > 200) {
    const oldest = sessions.order.shift();
    if (oldest) sessions.map.delete(oldest);
  }
}

export function readSession(id: string): WorldState | null {
  const raw = bucket().map.get(id);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as WorldState;
  } catch {
    return null;
  }
}

export function newSessionId() {
  return crypto.randomUUID();
}
