// 阶段与身份
export type StageId = "recluse" | "warlord" | "sovereign"; // 顺民乡绅 -> 割据军阀(听调不听宣) -> 问鼎称王

export const LOCATIONS = ["manor", "workshop", "yamen", "fort", "bandit_camp", "market"] as const;
export type LocationId = (typeof LOCATIONS)[number];

// 格物与韬略谱 (四大支干)
export const TECH_IDS = [
  "soap",          // 胰子草木灰皂
  "glass",         // 澄澈琉璃镜
  "liquor",        // 蒸馏烧刀子
  "black_powder",  // 颗粒黑火药
  "deep_well",     // 穿井抗旱
  "granary",       // 义仓屯粮
  "rampart",       // 坞堡女墙
  "triage",        // 设立义所
  "spear_drill",   // 鸳鸯长枪阵
  "dan_blade",     // 戚家单刀法
  "three_eye",     // 三眼火铳
  "iron_armor",    // 锻造明光铠
  "cry_poor",      // 公堂哭穷术
  "shift_blame",   // 移花接木
  "bribe_clerk",   // 收买三班胥吏
  "rebel_link",    // 暗通义军信使
] as const;
export type TechId = (typeof TECH_IDS)[number];
export type TechBranch = "science" | "clan" | "military" | "intrigue";

export type PortraitId =
  | "patriarch"
  | "accountant"
  | "magistrate"
  | "officer"
  | "envoy"
  | "bandit_boss";

export type Temperament = "brute" | "fox";

export type EndingId = "executed" | "assassinated" | "subdued" | "warlord_triumph" | "emperor";

export type CombatAction = "attack" | "defend" | "art" | "item" | "flee";

export interface Delta {
  field: "silver" | "grain" | "troops" | "population" | "fame" | "suspicion";
  delta: number;
  reason: string;
}

export interface Slip {
  intent: string;
  reactions: string;
  deltas: Delta[];
  hook: string;
  source: "llm" | "rule";
}

export interface NpcState {
  id: string;
  name: string;
  role: string;
  location: LocationId;
  attitude: number;
  portrait: PortraitId;
  lines: string[];
}

export interface Fighter {
  name: string;
  portrait: PortraitId;
  hp: number;
  hpMax: number;
  qi: number;
  qiMax: number;
  parry: number;
  agility: number;
  weapon: number;
  bleed: number;
  internal: number;
  broken: number;
  defending: boolean;
  temperament: Temperament;
}

export interface CombatRewards {
  silver: number;
  grain: number;
  fame: number;
  suspicionDelta: number;
  insight: number;
  description: string;
}

export interface CombatState {
  id: string;
  seed: number;
  round: number;
  encounterType: "skirmish" | "bandit_raid" | "bailiff_clash";
  player: Fighter;
  enemy: Fighter;
  log: string[];
  banter: string;
  over: null | "win" | "lose" | "flee";
  rewards?: CombatRewards | null;
  canFlee: boolean;
}

export interface WorldState {
  version: 3;
  stage: StageId;
  title: string;
  name: string;
  year: number;
  month: number;
  xun: "early" | "mid" | "late";
  energy: number;
  energyMax: number;
  turn: number;

  silver: number;
  grain: number;
  troops: number;
  population: number;
  fame: number;
  suspicion: number;

  insight: number;
  health: number;
  bandage: number;

  location: LocationId;
  unlocked: LocationId[];
  learned: TechId[];

  npcs: NpcState[];
  combat: CombatState | null;
  slip: Slip | null;
  report: string[];
  log: string[];
  ending: EndingId | null;
  epilogue: string | null;
  flags: Record<string, string | number | boolean>;
}

export type GameAction =
  | { type: "origin"; familyName?: string }
  | { type: "talk"; npcId: string; text: string }
  | { type: "act"; text: string; affair?: "clan" | "military" | "diplomacy" | "intrigue" }
  | { type: "affair_exec"; key: string }
  | { type: "start-fight"; encounter: "bandit_raid" | "skirmish" | "bailiff_clash" }
  | { type: "combat"; action: CombatAction; shout?: string }
  | { type: "settle_combat" } // 战后确认班师
  | { type: "travel"; to: LocationId }
  | { type: "pass_xun" }
  | { type: "learn"; techId: TechId }
  | { type: "ending"; ending: EndingId };
