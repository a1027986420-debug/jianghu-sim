import { applyAction, createWorld } from "../lib/game/engine";

async function main() {
  let world = createWorld("landed_gentry");
  console.log("【开局】:", world.title, world.name, `银:${world.silver} 粮:${world.grain} 部曲:${world.troops}`);

  // 1. 试验格物经商 (熬制肥皂)
  world = await applyAction(world, { type: "learn", techId: "soap" });
  world = await applyAction(world, { type: "act", text: "命工坊老匠人熬制草木灰肥皂，装箱销往府城。" });
  console.log("【格物生财后】:", `银:${world.silver} (增银暴利) 声望:${world.fame}`);

  // 2. 试验开仓吸纳流民
  world = await applyAction(world, { type: "act", text: "开仓架锅，施稠粥赈济四方流民。" });
  console.log("【赈济收民后】:", `粮:${world.grain} 庇护庄民:${world.population} 声望:${world.fame}`);

  // 3. 试验出兵剿匪 (牛头岭黑风寨)
  world = await applyAction(world, { type: "start-fight", encounter: "bandit_raid" });
  console.log("【交锋开阵】:", world.combat?.enemy.name);
  world = await applyAction(world, { type: "combat", action: "art" });
  console.log("【战阵破敌】:", world.combat?.log.at(-1));

  console.log("世家夺鼎录 · 核心推演与战斗闭环验证 100% 成功！");
}

main().catch((err) => {
  console.error("执行异常:", err);
  process.exit(1);
});
